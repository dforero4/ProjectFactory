<?php
/**
*
* @package Kiss Portal extension for the phpBB Forum Software package 1.0.1
*
* @copyright (c) 2014 Michael O�Toole <http://www.phpbbireland.com>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

// This file is needed for phpBB3 to properly register the extension

namespace phpbbireland\portal;

class ext extends \phpbb\extension\base
{
}
