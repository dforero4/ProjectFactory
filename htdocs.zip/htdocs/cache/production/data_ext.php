<?php exit; ?>
1525116431
338
a:2:{s:13:"phpbb/viglink";a:4:{s:8:"ext_name";s:13:"phpbb/viglink";s:10:"ext_active";s:1:"1";s:9:"ext_state";s:4:"b:0;";s:8:"ext_path";s:18:"ext/phpbb/viglink/";}s:19:"phpbbireland/portal";a:4:{s:8:"ext_name";s:19:"phpbbireland/portal";s:10:"ext_active";s:1:"1";s:9:"ext_state";s:4:"b:0;";s:8:"ext_path";s:24:"ext/phpbbireland/portal/";}}