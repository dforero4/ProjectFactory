<?php

/* @phpbbireland_portal/portal_header.html */
class __TwigTemplate_2986e1039e786877cd327be7427a52e6db6e34eddb3a3cf29d306b47fbc77664 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"blocks_hide_show_gap\">
\t";
        // line 2
        if ((isset($context["S_SHOW_LEFT_BLOCKS"]) ? $context["S_SHOW_LEFT_BLOCKS"] : null)) {
            // line 3
            echo "\t\t<span style=\"display:none;\" id=\"left_blocks_col_hide\">
\t\t\t<a href=\"javascript:ShowHide('left','left_blocks_col_hide','left_blocks_col_hide');ShowHide('left_blocks_col_show');\" title=\"Show Blocks\"><img src=\"";
            // line 4
            echo (isset($context["EXT_TEMPLATE_PATH"]) ? $context["EXT_TEMPLATE_PATH"] : null);
            echo "/theme/images/slide1.png\" width=\"12\" height=\"12\" alt=\"\" class=\"left_blocks_col_show\" /></a>
\t\t</span>
\t\t<span style=\"display:inline;\" id=\"left_blocks_col_show\">
\t\t\t<a href=\"javascript:ShowHide('left','left_blocks_col_show','left_blocks_col_hide');ShowHide('left_blocks_col_hide');\" title=\"Hide Blocks\"><img src=\"";
            // line 7
            echo (isset($context["EXT_TEMPLATE_PATH"]) ? $context["EXT_TEMPLATE_PATH"] : null);
            echo "/theme/images/slide2.png\" width=\"12\" height=\"12\"  alt=\"\" class=\"left_blocks_col_show\" /></a>
\t\t</span>
\t";
        }
        // line 10
        echo "\t";
        if ((isset($context["S_SHOW_RIGHT_BLOCKS"]) ? $context["S_SHOW_RIGHT_BLOCKS"] : null)) {
            // line 11
            echo "\t\t<span style=\"display:none; float:right;\" id=\"right_blocks_col_hide\">
\t\t\t<a href=\"javascript:ShowHide('right','right_blocks_col_hide','right_blocks_col_hide');ShowHide('right_blocks_col_show');\" title=\"Show Blocks\"><img src=\"";
            // line 12
            echo (isset($context["EXT_TEMPLATE_PATH"]) ? $context["EXT_TEMPLATE_PATH"] : null);
            echo "/theme/images/slide2.png\" width=\"12\" height=\"12\" alt=\"\" class=\"right_blocks_col_show\" /></a>
\t\t</span>
\t\t<span style=\"display:inline; float:right;\" id=\"right_blocks_col_show\">
\t\t\t<a href=\"javascript:ShowHide('right','right_blocks_col_show','right_blocks_col_hide');ShowHide('right_blocks_col_hide');\" title=\"Hide Blocks\"><img src=\"";
            // line 15
            echo (isset($context["EXT_TEMPLATE_PATH"]) ? $context["EXT_TEMPLATE_PATH"] : null);
            echo "/theme/images/slide1.png\" width=\"12\" height=\"12\" alt=\"\" class=\"right_blocks_col_show\" /></a>
\t\t</span>
\t";
        }
        // line 18
        echo "</div>

<div id=\"p_header_\">";
        // line 20
        if ((isset($context["PORTAL_HEADER_BLOCKS"]) ? $context["PORTAL_HEADER_BLOCKS"] : null)) {
            $location = "portal_header_blocks.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("portal_header_blocks.html", "@phpbbireland_portal/portal_header.html", 20)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
        }
        echo "</div>
<div id=\"p_container_\">
\t<div id=\"p_row_\">
\t\t";
        // line 23
        if ((isset($context["S_SHOW_LEFT_BLOCKS"]) ? $context["S_SHOW_LEFT_BLOCKS"] : null)) {
            // line 24
            echo "\t\t<div class=\"l_block_vert_gap\" style=\"width:";
            echo (isset($context["BLOCK_WIDTH"]) ? $context["BLOCK_WIDTH"] : null);
            echo ";\" id=\"left\">
\t\t\t<script type=\"text/javascript\">
\t\t\t\t// <![CDATA[
\t\t\t\tif(GetCookie('left_blocks_col_hide') == '2')
\t\t\t\t{
\t\t\t\t\tShowHide('left');
\t\t\t\t\tShowHide('left_blocks_col_hide');
\t\t\t\t\tShowHide('left_blocks_col_show');
\t\t\t\t}
\t\t\t\t// ]]>
\t\t\t</script>
\t\t\t";
            // line 35
            $location = "portal_layout_left.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("portal_layout_left.html", "@phpbbireland_portal/portal_header.html", 35)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
            // line 36
            echo "\t\t</div>
\t\t";
        }
        // line 38
        echo "\t\t<div id=\"center\">

";
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/portal_header.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 38,  108 => 36,  96 => 35,  81 => 24,  79 => 23,  61 => 20,  57 => 18,  51 => 15,  45 => 12,  42 => 11,  39 => 10,  33 => 7,  27 => 4,  24 => 3,  22 => 2,  19 => 1,);
    }
}
/* <div class="blocks_hide_show_gap">*/
/* 	<!-- IF S_SHOW_LEFT_BLOCKS -->*/
/* 		<span style="display:none;" id="left_blocks_col_hide">*/
/* 			<a href="javascript:ShowHide('left','left_blocks_col_hide','left_blocks_col_hide');ShowHide('left_blocks_col_show');" title="Show Blocks"><img src="{EXT_TEMPLATE_PATH}/theme/images/slide1.png" width="12" height="12" alt="" class="left_blocks_col_show" /></a>*/
/* 		</span>*/
/* 		<span style="display:inline;" id="left_blocks_col_show">*/
/* 			<a href="javascript:ShowHide('left','left_blocks_col_show','left_blocks_col_hide');ShowHide('left_blocks_col_hide');" title="Hide Blocks"><img src="{EXT_TEMPLATE_PATH}/theme/images/slide2.png" width="12" height="12"  alt="" class="left_blocks_col_show" /></a>*/
/* 		</span>*/
/* 	<!-- ENDIF -->*/
/* 	<!-- IF S_SHOW_RIGHT_BLOCKS -->*/
/* 		<span style="display:none; float:right;" id="right_blocks_col_hide">*/
/* 			<a href="javascript:ShowHide('right','right_blocks_col_hide','right_blocks_col_hide');ShowHide('right_blocks_col_show');" title="Show Blocks"><img src="{EXT_TEMPLATE_PATH}/theme/images/slide2.png" width="12" height="12" alt="" class="right_blocks_col_show" /></a>*/
/* 		</span>*/
/* 		<span style="display:inline; float:right;" id="right_blocks_col_show">*/
/* 			<a href="javascript:ShowHide('right','right_blocks_col_show','right_blocks_col_hide');ShowHide('right_blocks_col_hide');" title="Hide Blocks"><img src="{EXT_TEMPLATE_PATH}/theme/images/slide1.png" width="12" height="12" alt="" class="right_blocks_col_show" /></a>*/
/* 		</span>*/
/* 	<!-- ENDIF -->*/
/* </div>*/
/* */
/* <div id="p_header_"><!-- IF PORTAL_HEADER_BLOCKS --><!-- INCLUDE portal_header_blocks.html --><!-- ENDIF --></div>*/
/* <div id="p_container_">*/
/* 	<div id="p_row_">*/
/* 		<!-- IF S_SHOW_LEFT_BLOCKS -->*/
/* 		<div class="l_block_vert_gap" style="width:{BLOCK_WIDTH};" id="left">*/
/* 			<script type="text/javascript">*/
/* 				// <![CDATA[*/
/* 				if(GetCookie('left_blocks_col_hide') == '2')*/
/* 				{*/
/* 					ShowHide('left');*/
/* 					ShowHide('left_blocks_col_hide');*/
/* 					ShowHide('left_blocks_col_show');*/
/* 				}*/
/* 				// ]]>*/
/* 			</script>*/
/* 			<!-- INCLUDE portal_layout_left.html -->*/
/* 		</div>*/
/* 		<!-- ENDIF -->*/
/* 		<div id="center">*/
/* */
/* */
