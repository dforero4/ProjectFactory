<?php

/* @phpbbireland_portal/portal_layout_left.html */
class __TwigTemplate_5a80c91b6495b688e32fc9af9a4ae9891868e4ac7430cfc4432cb63a2cd11349 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "left_block_files", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["left_block_files"]) {
            // line 2
            echo "\t<div id=\"";
            if ((isset($context["S_ARRANGE"]) ? $context["S_ARRANGE"] : null)) {
                echo "BLOCK_";
            }
            echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCK_ID", array());
            echo "\">

\t\t<div class=\"forabg sgp-corners\" style=\"margin-bottom:10px;\">
\t\t\t<div class=\"inner\"><span class=\"corners-top\"><span></span></span>

\t\t\t\t<div class=\"block_header ";
            // line 7
            if ((isset($context["S_ARRANGE"]) ? $context["S_ARRANGE"] : null)) {
                echo "handle";
            }
            echo "\">
\t\t\t\t\t<div class=\"block_title\" style=\"text-align:";
            // line 8
            echo (isset($context["S_CONTENT_FLOW_BEGIN"]) ? $context["S_CONTENT_FLOW_BEGIN"] : null);
            echo ";\">";
            echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCK_TITLE", array());
            echo "
\t\t\t\t\t\t<div style=\"text-align:";
            // line 9
            echo (isset($context["S_CONTENT_FLOW_BEGIN"]) ? $context["S_CONTENT_FLOW_BEGIN"] : null);
            echo ";\" id=\"p_";
            echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCK_ID", array());
            echo "\">

\t\t\t\t\t\t\t";
            // line 11
            if ((isset($context["S_ARRANGE"]) ? $context["S_ARRANGE"] : null)) {
                // line 12
                echo "\t\t\t\t\t\t\t<span class=\"bmove\">";
                echo (isset($context["MOVE_IMG"]) ? $context["MOVE_IMG"] : null);
                echo "</span>
\t\t\t\t\t\t\t<a href=\"javascript:ShowHide('";
                // line 13
                echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCK_ID", array());
                echo "','_";
                echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCK_ID", array());
                echo "','BLOCK_";
                echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCK_ID", array());
                echo "');\">
\t\t\t\t\t\t\t\t<span class=\"bchide\">";
                // line 14
                echo (isset($context["HIDE_IMG"]) ? $context["HIDE_IMG"] : null);
                echo "</span>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t";
            } else {
                // line 17
                echo "\t\t\t\t\t\t\t<span class=\"bcimage\"><img src=\"";
                echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCK_IMG", array());
                echo "\" alt=\"\" /></span>
\t\t\t\t\t\t\t";
            }
            // line 19
            echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div class=\"box\" id=\"";
            // line 24
            if ( !(isset($context["S_ARRANGE"]) ? $context["S_ARRANGE"] : null)) {
                echo "BLOCK_";
            }
            echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCK_ID", array());
            echo "\">
\t\t\t\t\t";
            // line 25
            if ($this->getAttribute($context["left_block_files"], "LEFT_BLOCK_SCROLL", array())) {
                // line 26
                echo "\t\t\t\t\t\t";
                if ((isset($context["S_ARRANGE"]) ? $context["S_ARRANGE"] : null)) {
                    // line 27
                    echo "\t\t\t\t\t\t\t";
                    echo $this->env->getExtension('phpbb')->lang("SCROLLING_BLOCKS_DISABLED");
                    echo "
\t\t\t\t\t\t";
                } else {
                    // line 29
                    echo "\t\t\t\t\t\t\t<div class=\"scroll_outer\" id=\"";
                    echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCK_ID", array());
                    echo "_outer\" onmouseover=\"do_speed(this, event)\" onmousemove=\"do_speed(this, event)\" onmouseout=\"set_defaults(this, event)\"><div class=\"scroll_inner\" id=\"";
                    echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCK_ID", array());
                    echo "_inner\">";
                    echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCKS", array());
                    echo "</div></div>
\t\t\t\t\t\t";
                }
                // line 31
                echo "\t\t\t\t\t";
            } else {
                // line 32
                echo "\t\t\t\t\t\t";
                echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCKS", array());
                echo "
\t\t\t\t\t";
            }
            // line 34
            echo "\t\t\t\t</div>

\t\t\t<span class=\"corners-bottom\"><span></span></span></div>
\t\t</div>

\t\t<script type=\"text/javascript\">
\t\t// <![CDATA[
\t\t\tif(GetCookie('BLOCK_";
            // line 41
            echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCK_ID", array());
            echo "') == '2')
\t\t\t{
\t\t\t\tShowHide('";
            // line 43
            echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCK_ID", array());
            echo "','_";
            echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCK_ID", array());
            echo "','BLOCK_";
            echo $this->getAttribute($context["left_block_files"], "LEFT_BLOCK_ID", array());
            echo "');
\t\t\t}
\t\t// ]]>
\t\t</script>
\t</div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['left_block_files'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/portal_layout_left.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 43,  134 => 41,  125 => 34,  119 => 32,  116 => 31,  106 => 29,  100 => 27,  97 => 26,  95 => 25,  88 => 24,  81 => 19,  75 => 17,  69 => 14,  61 => 13,  56 => 12,  54 => 11,  47 => 9,  41 => 8,  35 => 7,  23 => 2,  19 => 1,);
    }
}
/* <!-- BEGIN left_block_files -->*/
/* 	<div id="<!-- IF S_ARRANGE -->BLOCK_<!-- ENDIF -->{left_block_files.LEFT_BLOCK_ID}">*/
/* */
/* 		<div class="forabg sgp-corners" style="margin-bottom:10px;">*/
/* 			<div class="inner"><span class="corners-top"><span></span></span>*/
/* */
/* 				<div class="block_header <!-- IF S_ARRANGE -->handle<!-- ENDIF -->">*/
/* 					<div class="block_title" style="text-align:{S_CONTENT_FLOW_BEGIN};">{left_block_files.LEFT_BLOCK_TITLE}*/
/* 						<div style="text-align:{S_CONTENT_FLOW_BEGIN};" id="p_{left_block_files.LEFT_BLOCK_ID}">*/
/* */
/* 							<!-- IF S_ARRANGE -->*/
/* 							<span class="bmove">{MOVE_IMG}</span>*/
/* 							<a href="javascript:ShowHide('{left_block_files.LEFT_BLOCK_ID}','_{left_block_files.LEFT_BLOCK_ID}','BLOCK_{left_block_files.LEFT_BLOCK_ID}');">*/
/* 								<span class="bchide">{HIDE_IMG}</span>*/
/* 							</a>*/
/* 							<!-- ELSE -->*/
/* 							<span class="bcimage"><img src="{left_block_files.LEFT_BLOCK_IMG}" alt="" /></span>*/
/* 							<!-- ENDIF -->*/
/* */
/* 						</div>*/
/* 					</div>*/
/* 				</div>*/
/* */
/* 				<div class="box" id="<!-- IF not S_ARRANGE -->BLOCK_<!-- ENDIF -->{left_block_files.LEFT_BLOCK_ID}">*/
/* 					<!-- IF left_block_files.LEFT_BLOCK_SCROLL -->*/
/* 						<!-- IF S_ARRANGE -->*/
/* 							{L_SCROLLING_BLOCKS_DISABLED}*/
/* 						<!-- ELSE -->*/
/* 							<div class="scroll_outer" id="{left_block_files.LEFT_BLOCK_ID}_outer" onmouseover="do_speed(this, event)" onmousemove="do_speed(this, event)" onmouseout="set_defaults(this, event)"><div class="scroll_inner" id="{left_block_files.LEFT_BLOCK_ID}_inner">{left_block_files.LEFT_BLOCKS}</div></div>*/
/* 						<!-- ENDIF -->*/
/* 					<!-- ELSE -->*/
/* 						{left_block_files.LEFT_BLOCKS}*/
/* 					<!-- ENDIF -->*/
/* 				</div>*/
/* */
/* 			<span class="corners-bottom"><span></span></span></div>*/
/* 		</div>*/
/* */
/* 		<script type="text/javascript">*/
/* 		// <![CDATA[*/
/* 			if(GetCookie('BLOCK_{left_block_files.LEFT_BLOCK_ID}') == '2')*/
/* 			{*/
/* 				ShowHide('{left_block_files.LEFT_BLOCK_ID}','_{left_block_files.LEFT_BLOCK_ID}','BLOCK_{left_block_files.LEFT_BLOCK_ID}');*/
/* 			}*/
/* 		// ]]>*/
/* 		</script>*/
/* 	</div>*/
/* <!-- END left_block_files -->*/
