<?php

/* @phpbbireland_portal/portal_copyright.html */
class __TwigTemplate_9b673eb98ad38aa4daaf2f1ea406286d885f533662a28609122c22aec84bc71a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<br />Portal: <a href=\"http://www.phpbbireland.com\"> Kiss Portal Extension</a> &copy; <a href=\"http://www.phpbb.com/community/memberlist.php?mode=viewprofile&amp;u=15915\">Michael O'Toole</a><br />
";
        // line 2
        if ((isset($context["STYLE_DATA"]) ? $context["STYLE_DATA"] : null)) {
            echo " ";
            echo (isset($context["STYLE_DATA"]) ? $context["STYLE_DATA"] : null);
            echo " <br />";
        }
        // line 3
        echo "
";
        // line 4
        if ((isset($context["S_K_FOOTER_IMAGES_ALLOW"]) ? $context["S_K_FOOTER_IMAGES_ALLOW"] : null)) {
            // line 5
            echo "<div class=\"portal_footer_images\">
\t<a rel=\"external\" href=\"http://phpbb.com\"> <img src=\"";
            // line 6
            echo (isset($context["ROOT_PATH"]) ? $context["ROOT_PATH"] : null);
            echo "ext/phpbbireland/portal/images/links/www.phpbb.gif\" alt=\"\" /></a>
\t<a rel=\"external\" href=\"http://www.phpbbireland.com\"> <img src=\"";
            // line 7
            echo (isset($context["ROOT_PATH"]) ? $context["ROOT_PATH"] : null);
            echo "ext/phpbbireland/portal/images/links/www.phpbbireland.gif\"  alt=\"\" /></a>
</div>
";
        }
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/portal_copyright.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 7,  36 => 6,  33 => 5,  31 => 4,  28 => 3,  22 => 2,  19 => 1,);
    }
}
/* <br />Portal: <a href="http://www.phpbbireland.com"> Kiss Portal Extension</a> &copy; <a href="http://www.phpbb.com/community/memberlist.php?mode=viewprofile&amp;u=15915">Michael O'Toole</a><br />*/
/* <!-- IF STYLE_DATA --> {STYLE_DATA} <br /><!-- ENDIF -->*/
/* */
/* <!-- IF S_K_FOOTER_IMAGES_ALLOW -->*/
/* <div class="portal_footer_images">*/
/* 	<a rel="external" href="http://phpbb.com"> <img src="{ROOT_PATH}ext/phpbbireland/portal/images/links/www.phpbb.gif" alt="" /></a>*/
/* 	<a rel="external" href="http://www.phpbbireland.com"> <img src="{ROOT_PATH}ext/phpbbireland/portal/images/links/www.phpbbireland.gif"  alt="" /></a>*/
/* </div>*/
/* <!-- ENDIF -->*/
