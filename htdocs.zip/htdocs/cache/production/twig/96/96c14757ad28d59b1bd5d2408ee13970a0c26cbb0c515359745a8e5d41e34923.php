<?php

/* @phpbbireland_portal/event/overall_footer_content_after.html */
class __TwigTemplate_a28bcb32cd4f96c6ca0d80c1a7f57fe2c1a867128e7241e422f0374be7319eda extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $location = "portal_footer.html";
        $namespace = false;
        if (strpos($location, '@') === 0) {
            $namespace = substr($location, 1, strpos($location, '/') - 1);
            $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
            $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
        }
        $this->loadTemplate("portal_footer.html", "@phpbbireland_portal/event/overall_footer_content_after.html", 1)->display($context);
        if ($namespace) {
            $this->env->setNamespaceLookUpOrder($previous_look_up_order);
        }
        // line 2
        echo "

";
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/event/overall_footer_content_after.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 2,  19 => 1,);
    }
}
/* <!-- INCLUDE portal_footer.html -->*/
/* */
/* */
/* */
