<?php

/* @phpbbireland_portal/blocks/block_online_users.html */
class __TwigTemplate_48c6acc4d2a63e4b625b7e9518ff5ea6a67d76912993b4b819b82744e42fd9f9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- IDTAG start block_online_users.html 17 March 2008 copyright phpbbireland.com 2007 -->
<div class=\"block_data\">
\t";
        // line 3
        if ((isset($context["IN_FORUMS"]) ? $context["IN_FORUMS"] : null)) {
            echo "<p>";
            echo (isset($context["TOTAL_USERS_ONLINE_SITEWIDE"]) ? $context["TOTAL_USERS_ONLINE_SITEWIDE"] : null);
            echo "</p>";
        } else {
            echo "<p>";
            echo (isset($context["TOTAL_USERS_ONLINE"]) ? $context["TOTAL_USERS_ONLINE"] : null);
            echo "</p>";
        }
        // line 4
        echo "\t<p>";
        echo (isset($context["RECORD_USERS"]) ? $context["RECORD_USERS"] : null);
        echo "<br /></p>
\t<p>";
        // line 5
        echo (isset($context["LOGGED_IN_USER_LIST"]) ? $context["LOGGED_IN_USER_LIST"] : null);
        echo " ";
        echo $this->env->getExtension('phpbb')->lang("ONLINE_EXPLAIN");
        echo "<br /></p>
\t<div style=\"text-align:center;\"><a href=\"";
        // line 6
        echo (isset($context["U_VIEWONLINE"]) ? $context["U_VIEWONLINE"] : null);
        echo "\">";
        echo $this->env->getExtension('phpbb')->lang("ONLINE_USERS_SHOW");
        echo "</a></div>
</div>
";
        // line 8
        if ((isset($context["DEBUG_QUERIES"]) ? $context["DEBUG_QUERIES"] : null)) {
            echo "<div class=\"block_data\">";
            echo (isset($context["ONLINE_USERS_DEBUG"]) ? $context["ONLINE_USERS_DEBUG"] : null);
            echo "</div>";
        }
        // line 9
        echo "<!-- IDTAG ends block_online_users -->";
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/blocks/block_online_users.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 9,  51 => 8,  44 => 6,  38 => 5,  33 => 4,  23 => 3,  19 => 1,);
    }
}
/* <!-- IDTAG start block_online_users.html 17 March 2008 copyright phpbbireland.com 2007 -->*/
/* <div class="block_data">*/
/* 	<!-- IF IN_FORUMS --><p>{TOTAL_USERS_ONLINE_SITEWIDE}</p><!-- ELSE --><p>{TOTAL_USERS_ONLINE}</p><!-- ENDIF -->*/
/* 	<p>{RECORD_USERS}<br /></p>*/
/* 	<p>{LOGGED_IN_USER_LIST} {L_ONLINE_EXPLAIN}<br /></p>*/
/* 	<div style="text-align:center;"><a href="{U_VIEWONLINE}">{L_ONLINE_USERS_SHOW}</a></div>*/
/* </div>*/
/* <!-- IF DEBUG_QUERIES --><div class="block_data">{ONLINE_USERS_DEBUG}</div><!-- ENDIF -->*/
/* <!-- IDTAG ends block_online_users -->*/
