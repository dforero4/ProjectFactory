<?php

/* @phpbbireland_portal/blocks/block_the_teams.html */
class __TwigTemplate_8fbfec7a6f1e8c15f94b2bd17f19b995f833e8a80ac9ac1043ea2b4062cc2727 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- IDTAG starts block_the_teams.html copyright phpbbireland.com 2007 -->
<div class=\"block_data\" style=\"padding: 0px; margin: 0px;\">
\t<div class=\"tcontainer\" style=\"padding-bottom:3px; margin-top:-2px;\">
\t\t";
        // line 4
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "loop", array()));
        $context['_iterated'] = false;
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["loop"]) {
            // line 5
            echo "\t\t\t";
            if ($this->getAttribute($context["loop"], "S_CHANGE", array())) {
                // line 6
                echo "\t\t\t\t<div>
\t\t\t\t\t<span class=\"tleft\" style=\"position: relative; float:left; text-align:left; width:100%;\"><b>";
                // line 7
                echo $this->getAttribute($context["loop"], "GROUP_NAME", array());
                echo "</b></span>
\t\t\t\t</div>
\t\t\t";
            }
            // line 10
            echo "\t\t\t<div class=\"tcontainer\">
\t\t\t\t<div class=\"trow\" style=\"width:100%;\">
\t\t\t\t\t<span class=\"bg2 tleft\" style=\"position: relative; float:left; text-align:left; height:18px; width:18px;\"><img src=\"";
            // line 12
            echo $this->getAttribute($context["loop"], "GROUP_IMG_PATH", array());
            echo $this->getAttribute($context["loop"], "GROUP_IMG", array());
            echo "\" width=\"16\" height=\"16\" alt=\"";
            echo $this->getAttribute($context["loop"], "GROUP_IMG", array());
            echo "\" /></span>
\t\t\t\t\t<span class=\"bg2 tleft\" style=\"padding:1px; width:100%; overflow:hidden;\"><strong>";
            // line 13
            echo $this->getAttribute($context["loop"], "USERNAME_FULL", array());
            echo "</strong></span>
\t\t\t\t\t";
            // line 14
            if ($this->getAttribute($context["loop"], "COUNTRY_FLAG_IMG", array())) {
                echo "<span class=\"bg2 tleft\" style=\"width: auto; float:right;\">";
                echo $this->getAttribute($context["loop"], "COUNTRY_FLAG_IMG", array());
                echo "</span>";
            }
            // line 15
            echo "\t\t\t\t</div>
\t\t\t</div>
\t\t";
            $context['_iterated'] = true;
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        if (!$context['_iterated']) {
            // line 18
            echo "\t\t\t<div style=\"text-align:center;\">";
            echo $this->env->getExtension('phpbb')->lang("NO_TEAMS");
            echo "</div>
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['loop'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "\t</div>
\t";
        // line 21
        if (((isset($context["L_TEAM_MAX_COUNT"]) ? $context["L_TEAM_MAX_COUNT"] : null) != "")) {
            echo "<div class=\"block_data\"style=\"text-align:center;\" title=\"";
            echo $this->env->getExtension('phpbb')->lang("TEAM_MAX_COUNT");
            echo "\">";
            echo $this->env->getExtension('phpbb')->lang("TEAM_MAX_COUNT");
            echo "</div>";
        }
        // line 22
        echo "</div>
";
        // line 23
        if ((isset($context["DEBUG_QUERIES"]) ? $context["DEBUG_QUERIES"] : null)) {
            echo "<div class=\"block_data\">";
            echo (isset($context["THE_TEAM_DEBUG"]) ? $context["THE_TEAM_DEBUG"] : null);
            echo "</div>";
        }
        // line 24
        echo "<!-- IDTAG ends block_the_teams.html -->";
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/blocks/block_the_teams.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 24,  113 => 23,  110 => 22,  102 => 21,  99 => 20,  90 => 18,  75 => 15,  69 => 14,  65 => 13,  58 => 12,  54 => 10,  48 => 7,  45 => 6,  42 => 5,  24 => 4,  19 => 1,);
    }
}
/* <!-- IDTAG starts block_the_teams.html copyright phpbbireland.com 2007 -->*/
/* <div class="block_data" style="padding: 0px; margin: 0px;">*/
/* 	<div class="tcontainer" style="padding-bottom:3px; margin-top:-2px;">*/
/* 		<!-- BEGIN loop -->*/
/* 			<!-- IF loop.S_CHANGE -->*/
/* 				<div>*/
/* 					<span class="tleft" style="position: relative; float:left; text-align:left; width:100%;"><b>{loop.GROUP_NAME}</b></span>*/
/* 				</div>*/
/* 			<!-- ENDIF -->*/
/* 			<div class="tcontainer">*/
/* 				<div class="trow" style="width:100%;">*/
/* 					<span class="bg2 tleft" style="position: relative; float:left; text-align:left; height:18px; width:18px;"><img src="{loop.GROUP_IMG_PATH}{loop.GROUP_IMG}" width="16" height="16" alt="{loop.GROUP_IMG}" /></span>*/
/* 					<span class="bg2 tleft" style="padding:1px; width:100%; overflow:hidden;"><strong>{loop.USERNAME_FULL}</strong></span>*/
/* 					<!-- IF loop.COUNTRY_FLAG_IMG --><span class="bg2 tleft" style="width: auto; float:right;">{loop.COUNTRY_FLAG_IMG}</span><!-- ENDIF -->*/
/* 				</div>*/
/* 			</div>*/
/* 		<!-- BEGINELSE -->*/
/* 			<div style="text-align:center;">{L_NO_TEAMS}</div>*/
/* 		<!-- END loop -->*/
/* 	</div>*/
/* 	<!-- IF L_TEAM_MAX_COUNT != '' --><div class="block_data"style="text-align:center;" title="{L_TEAM_MAX_COUNT}">{L_TEAM_MAX_COUNT}</div><!-- ENDIF -->*/
/* </div>*/
/* <!-- IF DEBUG_QUERIES --><div class="block_data">{THE_TEAM_DEBUG}</div><!-- ENDIF -->*/
/* <!-- IDTAG ends block_the_teams.html -->*/
