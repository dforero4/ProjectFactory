<?php

/* @phpbbireland_portal/portal_config.html */
class __TwigTemplate_76d80206995af711b51301d6b73e7aa6542478e10124cd17a24b9b59cbba155c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/portal_config.html";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
