<?php

/* @phpbbireland_portal/blocks/block_menus_links.html */
class __TwigTemplate_44a043d5736461729fb0462d660b1099c888460c1636094bbc54a1c7166dc077 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- IDTAG starts block_menus.html 13 September 2007 copyright phpbbireland.com 2007 -->
<div class=\"block_data\">
\t<div id=\"menu_links\" class=\"sdmenu\">
\t\t<div class=\"nav_menu\">
\t\t\t";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "portal_link_menus_row", array()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["portal_link_menus_row"]) {
            // line 6
            echo "\t\t\t\t";
            if ($this->getAttribute($context["portal_link_menus_row"], "S_SUB_HEADING", array())) {
                // line 7
                echo "\t\t\t\t\t<span class=\"sub_heading\">";
                echo $this->getAttribute($context["portal_link_menus_row"], "PORTAL_LINK_MENU_HEAD_NAME", array());
                echo "</span>
\t\t\t\t";
            } else {
                // line 9
                echo "\t\t\t\t\t<span class=\"menu_item\">
\t\t\t\t\t";
                // line 10
                if ($this->getAttribute($context["portal_link_menus_row"], "PORTAL_LINK_MENU_ICON", array())) {
                    echo $this->getAttribute($context["portal_link_menus_row"], "PORTAL_LINK_MENU_ICON", array());
                }
                // line 11
                echo "\t\t\t\t\t\t<a href=\"";
                echo $this->getAttribute($context["portal_link_menus_row"], "U_PORTAL_LINK_MENU_LINK", array());
                echo "\" ";
                echo $this->getAttribute($context["portal_link_menus_row"], "LINK_OPTION", array());
                echo " >";
                echo $this->getAttribute($context["portal_link_menus_row"], "PORTAL_LINK_MENU_NAME", array());
                echo "</a>
\t\t\t\t\t</span>
\t\t\t\t\t";
                // line 13
                if (($this->getAttribute($context["portal_link_menus_row"], "S_SOFT_HR", array()) == 1)) {
                    echo "</div> <br /><img src=\"./images/soft_hr.gif\" />";
                }
                // line 14
                echo "\t\t\t\t";
            }
            // line 15
            echo "\t\t\t";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 16
            echo "\t\t\t\t<div style=\"text-align:center;\">";
            echo $this->env->getExtension('phpbb')->lang("NO_MENU");
            echo "</div>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['portal_link_menus_row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "\t\t</div>
\t</div>
</div>
";
        // line 21
        if ((isset($context["DEBUG_QUERIES"]) ? $context["DEBUG_QUERIES"] : null)) {
            echo "<div class=\"block_data\">";
            echo (isset($context["SUB_MENUS_DEBUG"]) ? $context["SUB_MENUS_DEBUG"] : null);
            echo "</div>";
        }
        // line 22
        echo "<!-- IDTAG block_menus ends -->";
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/blocks/block_menus_links.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 22,  82 => 21,  77 => 18,  68 => 16,  63 => 15,  60 => 14,  56 => 13,  46 => 11,  42 => 10,  39 => 9,  33 => 7,  30 => 6,  25 => 5,  19 => 1,);
    }
}
/* <!-- IDTAG starts block_menus.html 13 September 2007 copyright phpbbireland.com 2007 -->*/
/* <div class="block_data">*/
/* 	<div id="menu_links" class="sdmenu">*/
/* 		<div class="nav_menu">*/
/* 			<!-- BEGIN portal_link_menus_row -->*/
/* 				<!-- IF portal_link_menus_row.S_SUB_HEADING -->*/
/* 					<span class="sub_heading">{portal_link_menus_row.PORTAL_LINK_MENU_HEAD_NAME}</span>*/
/* 				<!-- ELSE -->*/
/* 					<span class="menu_item">*/
/* 					<!-- IF portal_link_menus_row.PORTAL_LINK_MENU_ICON -->{portal_link_menus_row.PORTAL_LINK_MENU_ICON}<!-- ENDIF -->*/
/* 						<a href="{portal_link_menus_row.U_PORTAL_LINK_MENU_LINK}" {portal_link_menus_row.LINK_OPTION} >{portal_link_menus_row.PORTAL_LINK_MENU_NAME}</a>*/
/* 					</span>*/
/* 					<!-- IF portal_link_menus_row.S_SOFT_HR == 1 --></div> <br /><img src="./images/soft_hr.gif" /><!-- ENDIF -->*/
/* 				<!-- ENDIF -->*/
/* 			<!-- BEGINELSE -->*/
/* 				<div style="text-align:center;">{L_NO_MENU}</div>*/
/* 			<!-- END portal_link_menus_row -->*/
/* 		</div>*/
/* 	</div>*/
/* </div>*/
/* <!-- IF DEBUG_QUERIES --><div class="block_data">{SUB_MENUS_DEBUG}</div><!-- ENDIF -->*/
/* <!-- IDTAG block_menus ends -->*/
