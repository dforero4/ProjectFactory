<?php

/* @phpbbireland_portal/blocks/block_menus_nav.html */
class __TwigTemplate_7cc94bf2f46f9140d6db70966fd4b6de8d73e6d921a338645f99df009ccbeb2e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- IDTAG starts block_menus.html 13 September 2007 copyright phpbbireland.com 2007 -->
<div class=\"block_data\">
\t<div id=\"my_menu\" class=\"sdmenu\">
\t\t<div class=\"nav_menu\">
\t\t\t";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "portal_nav_menus_row", array()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["portal_nav_menus_row"]) {
            // line 6
            echo "\t\t\t\t";
            if ($this->getAttribute($context["portal_nav_menus_row"], "S_SUB_HEADING", array())) {
                // line 7
                echo "\t\t\t\t\t<span class=\"sub_heading\">";
                echo $this->getAttribute($context["portal_nav_menus_row"], "PORTAL_MENU_HEAD_NAME", array());
                echo "</span>
\t\t\t\t";
            } else {
                // line 9
                echo "\t\t\t\t\t<span class=\"menu_item\">
\t\t\t\t\t";
                // line 10
                if ($this->getAttribute($context["portal_nav_menus_row"], "PORTAL_MENU_ICON", array())) {
                    echo $this->getAttribute($context["portal_nav_menus_row"], "PORTAL_MENU_ICON", array());
                }
                // line 11
                echo "\t\t\t\t\t\t<a href=\"";
                echo $this->getAttribute($context["portal_nav_menus_row"], "U_PORTAL_MENU_LINK", array());
                echo "\" ";
                echo $this->getAttribute($context["portal_nav_menus_row"], "PORTAL_LINK_OPTION", array());
                echo " >
\t\t\t\t\t\t";
                // line 12
                echo $this->getAttribute($context["portal_nav_menus_row"], "PORTAL_MENU_NAME", array());
                echo "</a>
\t\t\t\t\t</span>
\t\t\t\t\t";
                // line 14
                if (($this->getAttribute($context["portal_nav_menus_row"], "S_SOFT_HR", array()) == 1)) {
                    echo "</div> <br /><img src=\"./images/soft_hr.gif\" alt=\"\" />";
                }
                // line 15
                echo "\t\t\t\t";
            }
            // line 16
            echo "\t\t\t";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 17
            echo "\t\t\t\t<div style=\"text-align:center;\">";
            echo $this->env->getExtension('phpbb')->lang("NO_MENU");
            echo "</div>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['portal_nav_menus_row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "\t\t</div>
\t</div>
</div>
";
        // line 22
        if ((isset($context["DEBUG_QUERIES"]) ? $context["DEBUG_QUERIES"] : null)) {
            echo "<div class=\"block_data\">";
            echo (isset($context["MENUS_DEBUG"]) ? $context["MENUS_DEBUG"] : null);
            echo "</div>";
        }
        // line 23
        echo "<!-- IDTAG block_menus ends -->";
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/blocks/block_menus_nav.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 23,  84 => 22,  79 => 19,  70 => 17,  65 => 16,  62 => 15,  58 => 14,  53 => 12,  46 => 11,  42 => 10,  39 => 9,  33 => 7,  30 => 6,  25 => 5,  19 => 1,);
    }
}
/* <!-- IDTAG starts block_menus.html 13 September 2007 copyright phpbbireland.com 2007 -->*/
/* <div class="block_data">*/
/* 	<div id="my_menu" class="sdmenu">*/
/* 		<div class="nav_menu">*/
/* 			<!-- BEGIN portal_nav_menus_row -->*/
/* 				<!-- IF portal_nav_menus_row.S_SUB_HEADING -->*/
/* 					<span class="sub_heading">{portal_nav_menus_row.PORTAL_MENU_HEAD_NAME}</span>*/
/* 				<!-- ELSE -->*/
/* 					<span class="menu_item">*/
/* 					<!-- IF portal_nav_menus_row.PORTAL_MENU_ICON -->{portal_nav_menus_row.PORTAL_MENU_ICON}<!-- ENDIF -->*/
/* 						<a href="{portal_nav_menus_row.U_PORTAL_MENU_LINK}" {portal_nav_menus_row.PORTAL_LINK_OPTION} >*/
/* 						{portal_nav_menus_row.PORTAL_MENU_NAME}</a>*/
/* 					</span>*/
/* 					<!-- IF portal_nav_menus_row.S_SOFT_HR == 1 --></div> <br /><img src="./images/soft_hr.gif" alt="" /><!-- ENDIF -->*/
/* 				<!-- ENDIF -->*/
/* 			<!-- BEGINELSE -->*/
/* 				<div style="text-align:center;">{L_NO_MENU}</div>*/
/* 			<!-- END portal_nav_menus_row -->*/
/* 		</div>*/
/* 	</div>*/
/* </div>*/
/* <!-- IF DEBUG_QUERIES --><div class="block_data">{MENUS_DEBUG}</div><!-- ENDIF -->*/
/* <!-- IDTAG block_menus ends -->*/
