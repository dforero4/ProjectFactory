<?php

/* @phpbbireland_portal/blocks/block_last_online.html */
class __TwigTemplate_bde52e0cf17b3166d4ff9ff31c291a9ce24a2025276aa9c36080d94ef9b8cc0e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- IDTAG starts block_last_online.html 4 November 2008 copyright phpbbireland.com 2008 -->
<div class=\"block_data\">
";
        // line 3
        if ((isset($context["VIEWONLINE"]) ? $context["VIEWONLINE"] : null)) {
            // line 4
            echo "\t<div style=\"clear:both;\">
\t\t<span style=\"position: relative; float:left; text-align:left; width:70%;\"><b>";
            // line 5
            echo $this->env->getExtension('phpbb')->lang("USERNAME");
            echo "</b></span>
\t\t<span style=\"position: relative; float:right; text-align:right; width:30%;\"><b>";
            // line 6
            echo $this->env->getExtension('phpbb')->lang("ONLINE");
            echo "</b></span>
\t</div>

\t";
            // line 9
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "last_online", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["last_online"]) {
                // line 10
                echo "\t<div class=\"tcontainer\" style=\"padding:1px; margin:0;\">
\t\t<div class=\"trow small_avatar\" style=\"width:100%;\">
\t\t\t<span class=\"tleft bg2\" style=\"padding:0px;\">
\t\t\t\t";
                // line 13
                if ($this->getAttribute($context["last_online"], "USER_AVATAR_IMG", array())) {
                    // line 14
                    echo "\t\t\t\t\t";
                    echo $this->getAttribute($context["last_online"], "USER_AVATAR_IMG", array());
                    echo "
\t\t\t\t";
                } else {
                    // line 16
                    echo "\t\t\t\t\t<img src=\"";
                    echo (isset($context["EXT_TEMPLATE_PATH"]) ? $context["EXT_TEMPLATE_PATH"] : null);
                    echo "/theme/images/no_avatar.gif\" width=\"16\" height=\"16\" alt=\"\" />
\t\t\t\t";
                }
                // line 18
                echo "\t\t\t</span>
\t\t\t<span class=\"tleft bg2\" style=\"width: auto; padding:1px;\">";
                // line 19
                echo $this->getAttribute($context["last_online"], "USERNAME_FULL", array());
                echo "</span>
\t\t\t<span class=\"tleft bg2\" style=\"width: 160px; padding:1px; font-size: 10px; text-align: right; overflow: hidden;\">";
                // line 20
                echo $this->getAttribute($context["last_online"], "ONLINE_TIME", array());
                echo "</span>
\t\t</div>
\t</div>
\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['last_online'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 24
            echo "
";
        }
        // line 26
        echo "
";
        // line 27
        if ((isset($context["NO_VIEWONLINE_R"]) ? $context["NO_VIEWONLINE_R"] : null)) {
            // line 28
            echo "\t<div style=\"text-align:center;\">
          <strong>";
            // line 29
            echo $this->env->getExtension('phpbb')->lang("NO_VIEW_USERS_R");
            echo "</strong>
\t\t<br />
\t</div>
";
        }
        // line 33
        if ((isset($context["NO_VIEWONLINE_A"]) ? $context["NO_VIEWONLINE_A"] : null)) {
            // line 34
            echo "\t<div style=\"text-align:center;\">
\t\t<form method=\"post\" action=\"";
            // line 35
            echo (isset($context["S_LOGIN_ACTION"]) ? $context["S_LOGIN_ACTION"] : null);
            echo "\" class=\"headerspace\">
\t\t<div>
\t\t\t<strong>";
            // line 37
            echo $this->env->getExtension('phpbb')->lang("NO_VIEW_USERS_A");
            echo "</strong>
\t\t\t<br /><br />
\t\t\t<input type=\"submit\" class=\"button2\" name=\"";
            // line 39
            echo $this->env->getExtension('phpbb')->lang("LOGIN");
            echo "\" value=\"";
            echo $this->env->getExtension('phpbb')->lang("LOGIN");
            echo "\"></input>
\t\t\t<br /><br />
\t\t\t<p>";
            // line 41
            echo $this->env->getExtension('phpbb')->lang("DONT_HAVE_ACCOUNT");
            echo "</p>
\t\t\t<a href=\"ucp.php?cid=&amp;mode=register\">";
            // line 42
            echo $this->env->getExtension('phpbb')->lang("REGISTRATION");
            echo "</a>
\t\t</div>
\t\t</form>
\t\t<br />
\t</div>
";
        }
        // line 48
        echo "</div>
";
        // line 49
        if ((isset($context["DEBUG_QUERIES"]) ? $context["DEBUG_QUERIES"] : null)) {
            echo "<div class=\"block_data\">";
            echo (isset($context["LAST_ONLINE_DEBUG"]) ? $context["LAST_ONLINE_DEBUG"] : null);
            echo "</div>";
        }
        // line 50
        echo "
<!-- IDTAG ends block_last_online.html -->

";
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/blocks/block_last_online.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  141 => 50,  135 => 49,  132 => 48,  123 => 42,  119 => 41,  112 => 39,  107 => 37,  102 => 35,  99 => 34,  97 => 33,  90 => 29,  87 => 28,  85 => 27,  82 => 26,  78 => 24,  68 => 20,  64 => 19,  61 => 18,  55 => 16,  49 => 14,  47 => 13,  42 => 10,  38 => 9,  32 => 6,  28 => 5,  25 => 4,  23 => 3,  19 => 1,);
    }
}
/* <!-- IDTAG starts block_last_online.html 4 November 2008 copyright phpbbireland.com 2008 -->*/
/* <div class="block_data">*/
/* <!-- IF VIEWONLINE -->*/
/* 	<div style="clear:both;">*/
/* 		<span style="position: relative; float:left; text-align:left; width:70%;"><b>{L_USERNAME}</b></span>*/
/* 		<span style="position: relative; float:right; text-align:right; width:30%;"><b>{L_ONLINE}</b></span>*/
/* 	</div>*/
/* */
/* 	<!-- BEGIN last_online -->*/
/* 	<div class="tcontainer" style="padding:1px; margin:0;">*/
/* 		<div class="trow small_avatar" style="width:100%;">*/
/* 			<span class="tleft bg2" style="padding:0px;">*/
/* 				<!-- IF last_online.USER_AVATAR_IMG -->*/
/* 					{last_online.USER_AVATAR_IMG}*/
/* 				<!-- ELSE -->*/
/* 					<img src="{EXT_TEMPLATE_PATH}/theme/images/no_avatar.gif" width="16" height="16" alt="" />*/
/* 				<!-- ENDIF -->*/
/* 			</span>*/
/* 			<span class="tleft bg2" style="width: auto; padding:1px;">{last_online.USERNAME_FULL}</span>*/
/* 			<span class="tleft bg2" style="width: 160px; padding:1px; font-size: 10px; text-align: right; overflow: hidden;">{last_online.ONLINE_TIME}</span>*/
/* 		</div>*/
/* 	</div>*/
/* 	<!-- END last_online -->*/
/* */
/* <!-- ENDIF -->*/
/* */
/* <!-- IF NO_VIEWONLINE_R -->*/
/* 	<div style="text-align:center;">*/
/*           <strong>{L_NO_VIEW_USERS_R}</strong>*/
/* 		<br />*/
/* 	</div>*/
/* <!-- ENDIF -->*/
/* <!-- IF NO_VIEWONLINE_A -->*/
/* 	<div style="text-align:center;">*/
/* 		<form method="post" action="{S_LOGIN_ACTION}" class="headerspace">*/
/* 		<div>*/
/* 			<strong>{L_NO_VIEW_USERS_A}</strong>*/
/* 			<br /><br />*/
/* 			<input type="submit" class="button2" name="{L_LOGIN}" value="{L_LOGIN}"></input>*/
/* 			<br /><br />*/
/* 			<p>{L_DONT_HAVE_ACCOUNT}</p>*/
/* 			<a href="ucp.php?cid=&amp;mode=register">{L_REGISTRATION}</a>*/
/* 		</div>*/
/* 		</form>*/
/* 		<br />*/
/* 	</div>*/
/* <!-- ENDIF -->*/
/* </div>*/
/* <!-- IF DEBUG_QUERIES --><div class="block_data">{LAST_ONLINE_DEBUG}</div><!-- ENDIF -->*/
/* */
/* <!-- IDTAG ends block_last_online.html -->*/
/* */
/* */
