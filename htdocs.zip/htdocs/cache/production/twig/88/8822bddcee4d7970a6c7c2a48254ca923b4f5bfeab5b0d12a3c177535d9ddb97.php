<?php

/* @phpbbireland_portal/portal_footer.html */
class __TwigTemplate_ab754cb507f4ceb44c0791928c2bebbbca222db0c26a04df3c54e4a038c7c35f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "
\t</div><!-- close center -->

\t\t";
        // line 4
        if ((isset($context["S_SHOW_RIGHT_BLOCKS"]) ? $context["S_SHOW_RIGHT_BLOCKS"] : null)) {
            // line 5
            echo "\t\t<div class=\"r_block_vert_gap\" style=\"width:";
            echo (isset($context["BLOCK_WIDTH"]) ? $context["BLOCK_WIDTH"] : null);
            echo ";\" id=\"right\">
\t\t\t<script type=\"text/javascript\">
\t\t\t\t// <![CDATA[
\t\t\t\tif(GetCookie('right_blocks_col_hide') == '2')
\t\t\t\t{
\t\t\t\t\tShowHide('right');
\t\t\t\t\tShowHide('right_blocks_col_hide');
\t\t\t\t\tShowHide('right_blocks_col_show');
\t\t\t\t}
\t\t\t\t// ]]>
\t\t\t</script>
\t\t\t";
            // line 16
            $location = "portal_layout_right.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("portal_layout_right.html", "@phpbbireland_portal/portal_footer.html", 16)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
            // line 17
            echo "\t\t</div>
\t\t";
        }
        // line 19
        echo "
\t</div><!-- close p_row_ -->
</div><!-- close p_container_ -->


\t<!-- Comment:
\tWe do not process the block move/arrange unless user select this option...
\tThis prevents js reports and ensures the scroll work correctly... Added: 09 March 2008 Mike.
\t-->
\t";
        // line 28
        if (((isset($context["S_IS_PORTAL"]) ? $context["S_IS_PORTAL"] : null) && (isset($context["S_ARRANGE"]) ? $context["S_ARRANGE"] : null))) {
            // line 29
            echo "\t<script type=\"text/javascript\">
\t// <![CDATA[
\t\tvar _left;
\t\tvar _right;
\t\tvar _center;

\t\t\$_left = GetCookie('";
            // line 35
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_left');
\t\t\$_center = GetCookie('";
            // line 36
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_center');
\t\t\$_right = GetCookie('";
            // line 37
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_right');

\t\tSetCookie('";
            // line 39
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_block_cache', '0');

\t\tSortable.create(\"left\",
\t\t\t{tag:'div',dropOnEmpty:true,handle:'handle',containment:[\"left\",\"center\",\"right\"],constraint:false,
\t\t\tonChange:
\t\t\t\tfunction()
\t\t\t\t{
\t\t\t\t\t\$_left = \$('leftdebug').innerHTML = Sortable.serialize('left');
\t\t\t\t\t\$_center = \$('centerdebug').innerHTML = Sortable.serialize('center');
\t\t\t\t\t\$_right = \$('rightdebug').innerHTML = Sortable.serialize('right');
\t\t\t\t\tSetCookie('";
            // line 49
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_left', \$_left);
\t\t\t\t\tSetCookie('";
            // line 50
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_center', \$_center);
\t\t\t\t\tSetCookie('";
            // line 51
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_right', \$_right);
\t\t\t\t}
\t\t\t});
\t\tSortable.create(\"center\",
\t\t\t{tag:'div',dropOnEmpty:true,handle:'handle',containment:[\"left\",\"center\",\"right\"],constraint:false,
\t\t\tonChange:
\t\t\t\tfunction()
\t\t\t\t{
\t\t\t\t\t\$_left = \$('leftdebug').innerHTML = Sortable.serialize('left');
\t\t\t\t\t\$_center = \$('centerdebug').innerHTML = Sortable.serialize('center');
\t\t\t\t\t\$_right = \$('rightdebug').innerHTML = Sortable.serialize('right');
\t\t\t\t\tSetCookie('";
            // line 62
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_left', \$_left);
\t\t\t\t\tSetCookie('";
            // line 63
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_center', \$_center);
\t\t\t\t\tSetCookie('";
            // line 64
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_right', \$_right);
\t\t\t\t}
\t\t\t});
\t\tSortable.create(\"right\",
\t\t\t{tag:'div',dropOnEmpty:true,handle:'handle',containment:[\"left\",\"center\",\"right\"],constraint:false,
\t\t\tonChange:
\t\t\t\tfunction()
\t\t\t\t{
\t\t\t\t\t\$_left = \$('leftdebug').innerHTML = Sortable.serialize('left');
\t\t\t\t\t\$_center = \$('centerdebug').innerHTML = Sortable.serialize('center');
\t\t\t\t\t\$_right = \$('rightdebug').innerHTML = Sortable.serialize('right');
\t\t\t\t\tSetCookie('";
            // line 75
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_left', \$_left);
\t\t\t\t\tSetCookie('";
            // line 76
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_center', \$_center);
\t\t\t\t\tSetCookie('";
            // line 77
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_right', \$_right);
\t\t\t\t}
\t\t\t});
\t// ]]>
\t</script>
\t\t<!-- DO NOT DELETE THIS CODE -->
\t\t<div style=\"display:none;\">
\t\t\t<pre id=\"leftdebug\"></pre>
\t\t\t<pre id=\"centerdebug\"></pre>
\t\t\t<pre id=\"rightdebug\"></pre>
\t\t</div>
\t";
        }
        // line 89
        echo "
\t";
        // line 90
        if (((isset($context["S_IS_PORTAL"]) ? $context["S_IS_PORTAL"] : null) &&  !(isset($context["S_ARRANGE"]) ? $context["S_ARRANGE"] : null))) {
            // line 91
            echo "\t<script type=\"text/javascript\">
\t// <![CDATA[
\t\tSetCookie('";
            // line 93
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_block_cache', '300');
\t // ]]>
\t</script>
\t";
        }
        // line 97
        echo "
\t";
        // line 98
        if ((isset($context["S_CLEAR_CACHE"]) ? $context["S_CLEAR_CACHE"] : null)) {
            // line 99
            echo "\t<script type=\"text/javascript\">
\t// <![CDATA[
\t\tSetCookie('";
            // line 101
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_block_cache', '0');
\t\tSetCookie('";
            // line 102
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_left', '', 0);
\t\tSetCookie('";
            // line 103
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_center', '', 0);
\t\tSetCookie('";
            // line 104
            echo (isset($context["COOKIE_NAME"]) ? $context["COOKIE_NAME"] : null);
            echo "_sgp_right', '', 0);
\t // ]]>
\t</script>
\t";
        }
        // line 108
        echo "

";
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/portal_footer.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  215 => 108,  208 => 104,  204 => 103,  200 => 102,  196 => 101,  192 => 99,  190 => 98,  187 => 97,  180 => 93,  176 => 91,  174 => 90,  171 => 89,  156 => 77,  152 => 76,  148 => 75,  134 => 64,  130 => 63,  126 => 62,  112 => 51,  108 => 50,  104 => 49,  91 => 39,  86 => 37,  82 => 36,  78 => 35,  70 => 29,  68 => 28,  57 => 19,  53 => 17,  41 => 16,  26 => 5,  24 => 4,  19 => 1,);
    }
}
/* */
/* 	</div><!-- close center -->*/
/* */
/* 		<!-- IF S_SHOW_RIGHT_BLOCKS -->*/
/* 		<div class="r_block_vert_gap" style="width:{BLOCK_WIDTH};" id="right">*/
/* 			<script type="text/javascript">*/
/* 				// <![CDATA[*/
/* 				if(GetCookie('right_blocks_col_hide') == '2')*/
/* 				{*/
/* 					ShowHide('right');*/
/* 					ShowHide('right_blocks_col_hide');*/
/* 					ShowHide('right_blocks_col_show');*/
/* 				}*/
/* 				// ]]>*/
/* 			</script>*/
/* 			<!-- INCLUDE portal_layout_right.html -->*/
/* 		</div>*/
/* 		<!-- ENDIF -->*/
/* */
/* 	</div><!-- close p_row_ -->*/
/* </div><!-- close p_container_ -->*/
/* */
/* */
/* 	<!-- Comment:*/
/* 	We do not process the block move/arrange unless user select this option...*/
/* 	This prevents js reports and ensures the scroll work correctly... Added: 09 March 2008 Mike.*/
/* 	-->*/
/* 	<!-- IF S_IS_PORTAL and S_ARRANGE -->*/
/* 	<script type="text/javascript">*/
/* 	// <![CDATA[*/
/* 		var _left;*/
/* 		var _right;*/
/* 		var _center;*/
/* */
/* 		$_left = GetCookie('{COOKIE_NAME}_sgp_left');*/
/* 		$_center = GetCookie('{COOKIE_NAME}_sgp_center');*/
/* 		$_right = GetCookie('{COOKIE_NAME}_sgp_right');*/
/* */
/* 		SetCookie('{COOKIE_NAME}_sgp_block_cache', '0');*/
/* */
/* 		Sortable.create("left",*/
/* 			{tag:'div',dropOnEmpty:true,handle:'handle',containment:["left","center","right"],constraint:false,*/
/* 			onChange:*/
/* 				function()*/
/* 				{*/
/* 					$_left = $('leftdebug').innerHTML = Sortable.serialize('left');*/
/* 					$_center = $('centerdebug').innerHTML = Sortable.serialize('center');*/
/* 					$_right = $('rightdebug').innerHTML = Sortable.serialize('right');*/
/* 					SetCookie('{COOKIE_NAME}_sgp_left', $_left);*/
/* 					SetCookie('{COOKIE_NAME}_sgp_center', $_center);*/
/* 					SetCookie('{COOKIE_NAME}_sgp_right', $_right);*/
/* 				}*/
/* 			});*/
/* 		Sortable.create("center",*/
/* 			{tag:'div',dropOnEmpty:true,handle:'handle',containment:["left","center","right"],constraint:false,*/
/* 			onChange:*/
/* 				function()*/
/* 				{*/
/* 					$_left = $('leftdebug').innerHTML = Sortable.serialize('left');*/
/* 					$_center = $('centerdebug').innerHTML = Sortable.serialize('center');*/
/* 					$_right = $('rightdebug').innerHTML = Sortable.serialize('right');*/
/* 					SetCookie('{COOKIE_NAME}_sgp_left', $_left);*/
/* 					SetCookie('{COOKIE_NAME}_sgp_center', $_center);*/
/* 					SetCookie('{COOKIE_NAME}_sgp_right', $_right);*/
/* 				}*/
/* 			});*/
/* 		Sortable.create("right",*/
/* 			{tag:'div',dropOnEmpty:true,handle:'handle',containment:["left","center","right"],constraint:false,*/
/* 			onChange:*/
/* 				function()*/
/* 				{*/
/* 					$_left = $('leftdebug').innerHTML = Sortable.serialize('left');*/
/* 					$_center = $('centerdebug').innerHTML = Sortable.serialize('center');*/
/* 					$_right = $('rightdebug').innerHTML = Sortable.serialize('right');*/
/* 					SetCookie('{COOKIE_NAME}_sgp_left', $_left);*/
/* 					SetCookie('{COOKIE_NAME}_sgp_center', $_center);*/
/* 					SetCookie('{COOKIE_NAME}_sgp_right', $_right);*/
/* 				}*/
/* 			});*/
/* 	// ]]>*/
/* 	</script>*/
/* 		<!-- DO NOT DELETE THIS CODE -->*/
/* 		<div style="display:none;">*/
/* 			<pre id="leftdebug"></pre>*/
/* 			<pre id="centerdebug"></pre>*/
/* 			<pre id="rightdebug"></pre>*/
/* 		</div>*/
/* 	<!-- ENDIF -->*/
/* */
/* 	<!-- IF S_IS_PORTAL and not S_ARRANGE -->*/
/* 	<script type="text/javascript">*/
/* 	// <![CDATA[*/
/* 		SetCookie('{COOKIE_NAME}_sgp_block_cache', '300');*/
/* 	 // ]]>*/
/* 	</script>*/
/* 	<!-- ENDIF -->*/
/* */
/* 	<!-- IF S_CLEAR_CACHE -->*/
/* 	<script type="text/javascript">*/
/* 	// <![CDATA[*/
/* 		SetCookie('{COOKIE_NAME}_sgp_block_cache', '0');*/
/* 		SetCookie('{COOKIE_NAME}_sgp_left', '', 0);*/
/* 		SetCookie('{COOKIE_NAME}_sgp_center', '', 0);*/
/* 		SetCookie('{COOKIE_NAME}_sgp_right', '', 0);*/
/* 	 // ]]>*/
/* 	</script>*/
/* 	<!-- ENDIF -->*/
/* */
/* */
/* */
