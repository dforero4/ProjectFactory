<?php

/* @phpbbireland_portal/blocks/block_menus_sub.html */
class __TwigTemplate_b93f20141291c3f2f118a7b2c9f24c5a6d06d1a7d3aa2dd9d3d32f37c3da1194 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- IDTAG starts block_menus.html 13 September 2007 copyright phpbbireland.com 2007 -->

<div class=\"block_data\">
\t<div id=\"menus_sub\" class=\"sdmenu\">
\t\t<div class=\"nav_menu\">
\t\t\t";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "portal_sub_menus_row", array()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["portal_sub_menus_row"]) {
            // line 7
            echo "\t\t\t\t";
            if ($this->getAttribute($context["portal_sub_menus_row"], "S_SUB_HEADING", array())) {
                // line 8
                echo "\t\t\t\t\t<span class=\"sub_heading\">";
                echo $this->getAttribute($context["portal_sub_menus_row"], "PORTAL_MENU_HEAD_NAME", array());
                echo "</span>
\t\t\t\t";
            } else {
                // line 10
                echo "\t\t\t\t\t<span class=\"menu_item\">
\t\t\t\t\t";
                // line 11
                if ($this->getAttribute($context["portal_sub_menus_row"], "PORTAL_MENU_ICON", array())) {
                    echo $this->getAttribute($context["portal_sub_menus_row"], "PORTAL_MENU_ICON", array());
                }
                // line 12
                echo "\t\t\t\t\t\t<a href=\"";
                echo $this->getAttribute($context["portal_sub_menus_row"], "U_PORTAL_MENU_LINK", array());
                echo "\" ";
                echo $this->getAttribute($context["portal_sub_menus_row"], "PORTAL_LINK_OPTION", array());
                echo " >";
                echo $this->getAttribute($context["portal_sub_menus_row"], "PORTAL_MENU_NAME", array());
                echo "</a>
\t\t\t\t\t</span>
\t\t\t\t\t";
                // line 14
                if (($this->getAttribute($context["portal_sub_menus_row"], "S_SOFT_HR", array()) == 1)) {
                    echo "</div> <br /><img src=\"./images/soft_hr.gif\" />";
                }
                // line 15
                echo "\t\t\t\t";
            }
            // line 16
            echo "\t\t\t";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 17
            echo "\t\t\t\t<div style=\"text-align:center;\">";
            echo $this->env->getExtension('phpbb')->lang("NO_MENU");
            echo "</div>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['portal_sub_menus_row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "\t\t</div>
\t</div>
</div>
";
        // line 22
        if ((isset($context["DEBUG_QUERIES"]) ? $context["DEBUG_QUERIES"] : null)) {
            echo "<div class=\"block_data\">";
            echo (isset($context["MENUS_DEBUG"]) ? $context["MENUS_DEBUG"] : null);
            echo "</div>";
        }
        // line 23
        echo "<!-- IDTAG block_menus ends -->";
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/blocks/block_menus_sub.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 23,  83 => 22,  78 => 19,  69 => 17,  64 => 16,  61 => 15,  57 => 14,  47 => 12,  43 => 11,  40 => 10,  34 => 8,  31 => 7,  26 => 6,  19 => 1,);
    }
}
/* <!-- IDTAG starts block_menus.html 13 September 2007 copyright phpbbireland.com 2007 -->*/
/* */
/* <div class="block_data">*/
/* 	<div id="menus_sub" class="sdmenu">*/
/* 		<div class="nav_menu">*/
/* 			<!-- BEGIN portal_sub_menus_row -->*/
/* 				<!-- IF portal_sub_menus_row.S_SUB_HEADING -->*/
/* 					<span class="sub_heading">{portal_sub_menus_row.PORTAL_MENU_HEAD_NAME}</span>*/
/* 				<!-- ELSE -->*/
/* 					<span class="menu_item">*/
/* 					<!-- IF portal_sub_menus_row.PORTAL_MENU_ICON -->{portal_sub_menus_row.PORTAL_MENU_ICON}<!-- ENDIF -->*/
/* 						<a href="{portal_sub_menus_row.U_PORTAL_MENU_LINK}" {portal_sub_menus_row.PORTAL_LINK_OPTION} >{portal_sub_menus_row.PORTAL_MENU_NAME}</a>*/
/* 					</span>*/
/* 					<!-- IF portal_sub_menus_row.S_SOFT_HR == 1 --></div> <br /><img src="./images/soft_hr.gif" /><!-- ENDIF -->*/
/* 				<!-- ENDIF -->*/
/* 			<!-- BEGINELSE -->*/
/* 				<div style="text-align:center;">{L_NO_MENU}</div>*/
/* 			<!-- END portal_sub_menus_row -->*/
/* 		</div>*/
/* 	</div>*/
/* </div>*/
/* <!-- IF DEBUG_QUERIES --><div class="block_data">{MENUS_DEBUG}</div><!-- ENDIF -->*/
/* <!-- IDTAG block_menus ends -->*/
