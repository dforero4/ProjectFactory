<?php

/* @phpbbireland_portal/event/overall_footer_breadcrumb_prepend.html */
class __TwigTemplate_30577c8e774c2b6087731e2835509b9944d52b7a46ad12a2553c8b0a153a78ee extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if ( !(isset($context["U_SITE_HOME"]) ? $context["U_SITE_HOME"] : null)) {
            // line 2
            echo "\t";
            if ((isset($context["U_PORTAL"]) ? $context["U_PORTAL"] : null)) {
                echo "<span class=\"crumb\"><a href=\"";
                echo (isset($context["U_PORTAL"]) ? $context["U_PORTAL"] : null);
                echo "\" data-navbar-reference=\"portal\">";
                if ( !(isset($context["U_SITE_HOME"]) ? $context["U_SITE_HOME"] : null)) {
                    echo "<i class=\"fa fa-home\"></i> ";
                }
                echo $this->env->getExtension('phpbb')->lang("PORTAL");
                echo "</a></span>";
            }
        }
        // line 4
        echo "
";
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/event/overall_footer_breadcrumb_prepend.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 4,  21 => 2,  19 => 1,);
    }
}
/* <!-- IF not U_SITE_HOME -->*/
/* 	<!-- IF U_PORTAL --><span class="crumb"><a href="{U_PORTAL}" data-navbar-reference="portal"><!-- IF not U_SITE_HOME --><i class="fa fa-home"></i> <!-- ENDIF -->{L_PORTAL}</a></span><!-- ENDIF -->*/
/* <!-- ENDIF -->*/
/* */
/* */
