<?php

/* @phpbbireland_portal/blocks/block_user_information.html */
class __TwigTemplate_1bfc057cbd401c42a6d66cb1b5fd15ce43051ea1e6547eb749b4f1ab7be5079f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"block_data\">
\t<form method=\"post\" action=\"";
        // line 2
        echo (isset($context["S_LOGIN_ACTION"]) ? $context["S_LOGIN_ACTION"] : null);
        echo "\" id=\"login\" class=\"headerspace\">

\t";
        // line 4
        if (( !(isset($context["S_USER_LOGGED_IN"]) ? $context["S_USER_LOGGED_IN"] : null) &&  !(isset($context["S_IS_BOT"]) ? $context["S_IS_BOT"] : null))) {
            // line 5
            echo "
\t\t<div style=\"text-align:center;\"><img src=\"";
            // line 6
            echo (isset($context["EXT_TEMPLATE_PATH"]) ? $context["EXT_TEMPLATE_PATH"] : null);
            echo "/theme/images/no_avatar.gif\" alt=\"\" /></div>
\t\t<div label for=\"username\">";
            // line 7
            echo $this->env->getExtension('phpbb')->lang("USERNAME");
            echo ":</label></div>
\t\t<div style=\"text-align:center;\"><input type=\"text\" tabindex=\"1\" name=\"username\" id=\"username\" size=\"20\" maxlength=\"40\" value=\"";
            // line 8
            echo (isset($context["USERNAME"]) ? $context["USERNAME"] : null);
            echo "\" class=\"inputbox autowidth\" /></div>
\t\t<div label for=\"password\">";
            // line 9
            echo $this->env->getExtension('phpbb')->lang("PASSWORD");
            echo ":</label></div>
\t\t<div style=\"text-align:center;\"><input type=\"password\" tabindex=\"2\" id=\"password\" name=\"password\" size=\"20\" maxlength=\"25\" class=\"inputbox autowidth\" /></div>

\t\t";
            // line 12
            if (((isset($context["S_DISPLAY_FULL_LOGIN"]) ? $context["S_DISPLAY_FULL_LOGIN"] : null) && ((isset($context["U_SEND_PASSWORD"]) ? $context["U_SEND_PASSWORD"] : null) || (isset($context["U_RESEND_ACTIVATION"]) ? $context["U_RESEND_ACTIVATION"] : null)))) {
                // line 13
                echo "\t\t\t";
                if ((isset($context["U_SEND_PASSWORD"]) ? $context["U_SEND_PASSWORD"] : null)) {
                    echo "<div style=\"text-align:center;\"><a href=\"";
                    echo (isset($context["U_SEND_PASSWORD"]) ? $context["U_SEND_PASSWORD"] : null);
                    echo "\">";
                    echo $this->env->getExtension('phpbb')->lang("FORGOT_PASS");
                    echo "</a></div>";
                }
                // line 14
                echo "\t\t\t";
                if ((isset($context["U_RESEND_ACTIVATION"]) ? $context["U_RESEND_ACTIVATION"] : null)) {
                    echo "<div style=\"text-align:center;\"><a href=\"";
                    echo (isset($context["U_RESEND_ACTIVATION"]) ? $context["U_RESEND_ACTIVATION"] : null);
                    echo "\">";
                    echo $this->env->getExtension('phpbb')->lang("RESEND_ACTIVATION");
                    echo "</a></div>";
                }
                // line 15
                echo "\t\t";
            }
            // line 16
            echo "
\t\t";
            // line 17
            if ((isset($context["S_AUTOLOGIN_ENABLED"]) ? $context["S_AUTOLOGIN_ENABLED"] : null)) {
                // line 18
                echo "\t\t<div style=\"text-align:center;\">
\t\t\t<label for=\"autologin\">";
                // line 19
                echo $this->env->getExtension('phpbb')->lang("LOG_ME_IN_SHORT");
                echo "</label>
\t\t\t<input type=\"checkbox\" name=\"autologin\" id=\"autologin\" tabindex=\"4\" class=\"checkbox\" />
\t\t</div>
\t\t";
            }
            // line 23
            echo "\t\t<div style=\"text-align:center;\">";
            echo (isset($context["S_HIDDEN_FIELDS"]) ? $context["S_HIDDEN_FIELDS"] : null);
            echo "<input type=\"submit\" class=\"button2\" name=\"login\" value=\"";
            echo $this->env->getExtension('phpbb')->lang("LOGIN");
            echo "\" /></div>
\t\t<div style=\"text-align:center;\" class=\"gensmall\">";
            // line 24
            echo $this->env->getExtension('phpbb')->lang("DONT_HAVE_ACCOUNT");
            echo "<a href=\"ucp.php?cid=&amp;mode=register\">";
            echo $this->env->getExtension('phpbb')->lang("REGISTRATION");
            echo "</a><br /></div>

\t";
        }
        // line 27
        echo "
\t";
        // line 28
        if ((isset($context["S_USER_LOGGED_IN"]) ? $context["S_USER_LOGGED_IN"] : null)) {
            // line 29
            echo "\t\t<div style=\"text-align:center;\">
\t\t\t";
            // line 30
            if ((isset($context["AVATAR"]) ? $context["AVATAR"] : null)) {
                echo (isset($context["AVATAR"]) ? $context["AVATAR"] : null);
            } else {
                echo "<img src=\"";
                echo (isset($context["EXT_TEMPLATE_PATH"]) ? $context["EXT_TEMPLATE_PATH"] : null);
                echo "/theme/images/no_avatar.gif\" alt=\"\" />";
            }
            // line 31
            echo "\t\t</div>

\t\t<div style=\"text-align:center;\">
\t\t\t<span class=\"welcome\">
\t\t\t";
            // line 35
            echo (isset($context["WELCOME_SITE"]) ? $context["WELCOME_SITE"] : null);
            echo "<br />
\t\t\t";
            // line 36
            if ((isset($context["USR_RANK_IMG"]) ? $context["USR_RANK_IMG"] : null)) {
                echo (isset($context["USR_RANK_TITLE"]) ? $context["USR_RANK_TITLE"] : null);
                echo "<br />";
                echo (isset($context["USR_RANK_IMG"]) ? $context["USR_RANK_IMG"] : null);
                echo "<br />";
            }
            // line 37
            echo "\t\t\t";
            echo (isset($context["P_USERNAME_FULL"]) ? $context["P_USERNAME_FULL"] : null);
            echo "
\t\t\t</span>
\t\t</div>
\t\t<div style=\"text-align:center; padding:3px;\">";
            // line 40
            if ((isset($context["S_USER_LOGGED_IN"]) ? $context["S_USER_LOGGED_IN"] : null)) {
                echo (isset($context["LAST_VISIT_DATE"]) ? $context["LAST_VISIT_DATE"] : null);
            } else {
                echo (isset($context["CURRENT_TIME"]) ? $context["CURRENT_TIME"] : null);
            }
            echo "</div>
\t\t<div style=\"text-align:center; padding:3px;\"><a href=\"";
            // line 41
            echo (isset($context["U_SEARCH_SELF"]) ? $context["U_SEARCH_SELF"] : null);
            echo "\">";
            echo $this->env->getExtension('phpbb')->lang("SEARCH_SELF");
            echo "</a></div>
\t\t<div style=\"text-align:center; padding:3px;\"><a href=\"";
            // line 42
            echo (isset($context["U_LOGIN_LOGOUT"]) ? $context["U_LOGIN_LOGOUT"] : null);
            echo "\"><img src=\"";
            echo (isset($context["EXT_TEMPLATE_PATH"]) ? $context["EXT_TEMPLATE_PATH"] : null);
            echo "/theme/images/icon_logout.gif\" width=\"12\" height=\"13\" alt=\"";
            echo $this->env->getExtension('phpbb')->lang("LOGIN_LOGOUT");
            echo "\" /> ";
            echo $this->env->getExtension('phpbb')->lang("LOGIN_LOGOUT");
            echo "</a></div>
\t";
        }
        // line 44
        echo "\t";
        echo (isset($context["S_LOGIN_REDIRECT"]) ? $context["S_LOGIN_REDIRECT"] : null);
        echo "
\t</form>
</div>
<!-- IDTAG ends block_user_information -->

";
        // line 49
        if ((isset($context["DEBUG_QUERIES"]) ? $context["DEBUG_QUERIES"] : null)) {
            echo "<div class=\"block_data\">";
            echo (isset($context["USER_INFORMATION_DEBUG"]) ? $context["USER_INFORMATION_DEBUG"] : null);
            echo "</div>";
        }
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/blocks/block_user_information.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  177 => 49,  168 => 44,  157 => 42,  151 => 41,  143 => 40,  136 => 37,  129 => 36,  125 => 35,  119 => 31,  111 => 30,  108 => 29,  106 => 28,  103 => 27,  95 => 24,  88 => 23,  81 => 19,  78 => 18,  76 => 17,  73 => 16,  70 => 15,  61 => 14,  52 => 13,  50 => 12,  44 => 9,  40 => 8,  36 => 7,  32 => 6,  29 => 5,  27 => 4,  22 => 2,  19 => 1,);
    }
}
/* <div class="block_data">*/
/* 	<form method="post" action="{S_LOGIN_ACTION}" id="login" class="headerspace">*/
/* */
/* 	<!-- IF not S_USER_LOGGED_IN and not S_IS_BOT -->*/
/* */
/* 		<div style="text-align:center;"><img src="{EXT_TEMPLATE_PATH}/theme/images/no_avatar.gif" alt="" /></div>*/
/* 		<div label for="username">{L_USERNAME}:</label></div>*/
/* 		<div style="text-align:center;"><input type="text" tabindex="1" name="username" id="username" size="20" maxlength="40" value="{USERNAME}" class="inputbox autowidth" /></div>*/
/* 		<div label for="password">{L_PASSWORD}:</label></div>*/
/* 		<div style="text-align:center;"><input type="password" tabindex="2" id="password" name="password" size="20" maxlength="25" class="inputbox autowidth" /></div>*/
/* */
/* 		<!-- IF S_DISPLAY_FULL_LOGIN and (U_SEND_PASSWORD or U_RESEND_ACTIVATION) -->*/
/* 			<!-- IF U_SEND_PASSWORD --><div style="text-align:center;"><a href="{U_SEND_PASSWORD}">{L_FORGOT_PASS}</a></div><!-- ENDIF -->*/
/* 			<!-- IF U_RESEND_ACTIVATION --><div style="text-align:center;"><a href="{U_RESEND_ACTIVATION}">{L_RESEND_ACTIVATION}</a></div><!-- ENDIF -->*/
/* 		<!-- ENDIF -->*/
/* */
/* 		<!-- IF S_AUTOLOGIN_ENABLED -->*/
/* 		<div style="text-align:center;">*/
/* 			<label for="autologin">{L_LOG_ME_IN_SHORT}</label>*/
/* 			<input type="checkbox" name="autologin" id="autologin" tabindex="4" class="checkbox" />*/
/* 		</div>*/
/* 		<!-- ENDIF -->*/
/* 		<div style="text-align:center;">{S_HIDDEN_FIELDS}<input type="submit" class="button2" name="login" value="{L_LOGIN}" /></div>*/
/* 		<div style="text-align:center;" class="gensmall">{L_DONT_HAVE_ACCOUNT}<a href="ucp.php?cid=&amp;mode=register">{L_REGISTRATION}</a><br /></div>*/
/* */
/* 	<!-- ENDIF -->*/
/* */
/* 	<!-- IF S_USER_LOGGED_IN -->*/
/* 		<div style="text-align:center;">*/
/* 			<!-- IF AVATAR -->{AVATAR}<!-- ELSE --><img src="{EXT_TEMPLATE_PATH}/theme/images/no_avatar.gif" alt="" /><!-- ENDIF -->*/
/* 		</div>*/
/* */
/* 		<div style="text-align:center;">*/
/* 			<span class="welcome">*/
/* 			{WELCOME_SITE}<br />*/
/* 			<!-- IF USR_RANK_IMG -->{USR_RANK_TITLE}<br />{USR_RANK_IMG}<br /><!-- ENDIF -->*/
/* 			{P_USERNAME_FULL}*/
/* 			</span>*/
/* 		</div>*/
/* 		<div style="text-align:center; padding:3px;"><!-- IF S_USER_LOGGED_IN -->{LAST_VISIT_DATE}<!-- ELSE -->{CURRENT_TIME}<!-- ENDIF --></div>*/
/* 		<div style="text-align:center; padding:3px;"><a href="{U_SEARCH_SELF}">{L_SEARCH_SELF}</a></div>*/
/* 		<div style="text-align:center; padding:3px;"><a href="{U_LOGIN_LOGOUT}"><img src="{EXT_TEMPLATE_PATH}/theme/images/icon_logout.gif" width="12" height="13" alt="{L_LOGIN_LOGOUT}" /> {L_LOGIN_LOGOUT}</a></div>*/
/* 	<!-- ENDIF -->*/
/* 	{S_LOGIN_REDIRECT}*/
/* 	</form>*/
/* </div>*/
/* <!-- IDTAG ends block_user_information -->*/
/* */
/* <!-- IF DEBUG_QUERIES --><div class="block_data">{USER_INFORMATION_DEBUG}</div><!-- ENDIF -->*/
