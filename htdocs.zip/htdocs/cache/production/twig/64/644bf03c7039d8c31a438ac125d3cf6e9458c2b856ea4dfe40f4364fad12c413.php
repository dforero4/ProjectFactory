<?php

/* @phpbbireland_portal/blocks/block_top_posters.html */
class __TwigTemplate_c3ebc2bc0783aa65868c146bcc506834981d3cce0913d1f253a1ed6fddd2ff8a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- IDTAG block_top_posters.html start 13 September 2007 -->
<div class=\"block_data\">
\t<div class=\"tcontainer\" style=\"padding-bottom:3px; margin-top:-2px;\">
\t\t<div>
\t\t\t<span style=\"position: relative; float:left; text-align:left; width:70%;\"><b>";
        // line 5
        echo $this->env->getExtension('phpbb')->lang("USERNAME");
        echo "</b></span>
\t\t\t<span style=\"position: relative; float:right; text-align:right; width:30%;\"><b>";
        // line 6
        echo $this->env->getExtension('phpbb')->lang("POSTS");
        echo "</b></span>
\t\t</div>
\t</div>

\t<div class=\"tcontainer\" style=\"padding:1px; margin:0;\">
\t\t";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "top_posters", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["top_posters"]) {
            // line 12
            echo "\t\t\t<div class=\"trow small_avatar\" style=\"width:100%;\">
\t\t\t";
            // line 13
            if (($this->getAttribute($context["top_posters"], "S_ROWS", array()) % 2 == 0)) {
                // line 14
                echo "\t\t\t\t<span class=\"tleft bg2\" style=\"padding:0px;\">";
                if ($this->getAttribute($context["top_posters"], "USER_AVATAR_IMG", array())) {
                    echo $this->getAttribute($context["top_posters"], "USER_AVATAR_IMG", array());
                } else {
                    echo "<img src=\"";
                    echo (isset($context["EXT_TEMPLATE_PATH"]) ? $context["EXT_TEMPLATE_PATH"] : null);
                    echo "/theme/images/no_avatar.gif\" width=\"16\" height=\"16\" alt=\"\" />";
                }
                echo "</span>
\t\t\t\t<span class=\"tleft bg2\" style=\"padding:1px; width:100%;\">";
                // line 15
                echo $this->getAttribute($context["top_posters"], "USERNAME_FULL", array());
                echo "</span>
\t\t\t\t<span class=\"tleft bg2\" style=\"padding:1px; width:auto; text-align:right; min-width:35px;\"><a href=\"";
                // line 16
                echo $this->getAttribute($context["top_posters"], "S_SEARCH_ACTION", array());
                echo "\">";
                echo $this->getAttribute($context["top_posters"], "POSTER_POSTS", array());
                echo "</a></span>
\t\t\t";
            } else {
                // line 18
                echo "\t\t\t\t<span class=\"tleft bg1\" style=\"padding:0px;\">";
                if ($this->getAttribute($context["top_posters"], "USER_AVATAR_IMG", array())) {
                    echo $this->getAttribute($context["top_posters"], "USER_AVATAR_IMG", array());
                } else {
                    echo "<img src=\"";
                    echo (isset($context["EXT_TEMPLATE_PATH"]) ? $context["EXT_TEMPLATE_PATH"] : null);
                    echo "/theme/images/no_avatar.gif\" width=\"16\" height=\"16\" alt=\"\" />";
                }
                echo "</span>
\t\t\t\t<span class=\"tleft bg1\" style=\"padding:1px; width:100%;\">";
                // line 19
                echo $this->getAttribute($context["top_posters"], "USERNAME_FULL", array());
                echo "</span>
\t\t\t\t<span class=\"tleft bg1\" style=\"padding:1px; width:auto; text-align:right; min-width:35px; overflow:hidden;\"><a href=\"";
                // line 20
                echo $this->getAttribute($context["top_posters"], "S_SEARCH_ACTION", array());
                echo "\">";
                echo $this->getAttribute($context["top_posters"], "POSTER_POSTS", array());
                echo "</a></span>
\t\t\t";
            }
            // line 22
            echo "\t\t\t</div>
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['top_posters'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "\t</div>

";
        // line 26
        if ((isset($context["DEBUG_QUERIES"]) ? $context["DEBUG_QUERIES"] : null)) {
            echo (isset($context["TOP_POSTERS_DEBUG"]) ? $context["TOP_POSTERS_DEBUG"] : null);
        }
        // line 27
        echo "</div>

<!-- IDTAG block_top_posters.html ends 15 April 2007 -->


";
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/blocks/block_top_posters.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 27,  101 => 26,  97 => 24,  90 => 22,  83 => 20,  79 => 19,  68 => 18,  61 => 16,  57 => 15,  46 => 14,  44 => 13,  41 => 12,  37 => 11,  29 => 6,  25 => 5,  19 => 1,);
    }
}
/* <!-- IDTAG block_top_posters.html start 13 September 2007 -->*/
/* <div class="block_data">*/
/* 	<div class="tcontainer" style="padding-bottom:3px; margin-top:-2px;">*/
/* 		<div>*/
/* 			<span style="position: relative; float:left; text-align:left; width:70%;"><b>{L_USERNAME}</b></span>*/
/* 			<span style="position: relative; float:right; text-align:right; width:30%;"><b>{L_POSTS}</b></span>*/
/* 		</div>*/
/* 	</div>*/
/* */
/* 	<div class="tcontainer" style="padding:1px; margin:0;">*/
/* 		<!-- BEGIN top_posters -->*/
/* 			<div class="trow small_avatar" style="width:100%;">*/
/* 			<!-- IF top_posters.S_ROWS is even -->*/
/* 				<span class="tleft bg2" style="padding:0px;"><!-- IF top_posters.USER_AVATAR_IMG -->{top_posters.USER_AVATAR_IMG}<!-- ELSE --><img src="{EXT_TEMPLATE_PATH}/theme/images/no_avatar.gif" width="16" height="16" alt="" /><!-- ENDIF --></span>*/
/* 				<span class="tleft bg2" style="padding:1px; width:100%;">{top_posters.USERNAME_FULL}</span>*/
/* 				<span class="tleft bg2" style="padding:1px; width:auto; text-align:right; min-width:35px;"><a href="{top_posters.S_SEARCH_ACTION}">{top_posters.POSTER_POSTS}</a></span>*/
/* 			<!-- ELSE -->*/
/* 				<span class="tleft bg1" style="padding:0px;"><!-- IF top_posters.USER_AVATAR_IMG -->{top_posters.USER_AVATAR_IMG}<!-- ELSE --><img src="{EXT_TEMPLATE_PATH}/theme/images/no_avatar.gif" width="16" height="16" alt="" /><!-- ENDIF --></span>*/
/* 				<span class="tleft bg1" style="padding:1px; width:100%;">{top_posters.USERNAME_FULL}</span>*/
/* 				<span class="tleft bg1" style="padding:1px; width:auto; text-align:right; min-width:35px; overflow:hidden;"><a href="{top_posters.S_SEARCH_ACTION}">{top_posters.POSTER_POSTS}</a></span>*/
/* 			<!-- ENDIF -->*/
/* 			</div>*/
/* 		<!-- END top_posters -->*/
/* 	</div>*/
/* */
/* <!-- IF DEBUG_QUERIES -->{TOP_POSTERS_DEBUG}<!-- ENDIF -->*/
/* </div>*/
/* */
/* <!-- IDTAG block_top_posters.html ends 15 April 2007 -->*/
/* */
/* */
/* */
