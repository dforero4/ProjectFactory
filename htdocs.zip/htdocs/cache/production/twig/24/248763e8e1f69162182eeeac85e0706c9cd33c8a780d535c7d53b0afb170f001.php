<?php

/* @phpbbireland_portal/blocks/block_search.html */
class __TwigTemplate_d4c8edd211d79abde251f2346e861140c7612e85c39ef3c8f5d530661857b8ba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- IDTAG starts block_search.html 17 March 2008 copyright phpbbireland.com 2007 -->
";
        // line 2
        if ((isset($context["S_SEARCH"]) ? $context["S_SEARCH"] : null)) {
            // line 3
            echo "
<script type=\"text/javascript\">
// <![CDATA[
function url_search()
{
\tswitch(document.forms['search_block'].search_engine.value)
\t{
\t\tcase 'advanced':
\t\t\t\t\t\twindow.open('";
            // line 11
            echo (isset($context["U_SEARCH"]) ? $context["U_SEARCH"] : null);
            echo "', '_self', '');
\t\t\t\t\t\treturn false;
\t\tcase 'google':
\t\t\t\t\t\twindow.open('http://www.google.com/search?q=' + document.forms['search_block'].keywords.value, '_google', '');
\t\t\t\t\t\treturn false;
\t\tcase 'yahoo':
\t\t\t\t\t\twindow.open('http://search.yahoo.com/search?p=' + document.forms['search_block'].keywords.value, '_yahoo', '');
\t\t\t\t\t\treturn false;
\t\tcase 'altavista':
\t\t\t\t\t\twindow.open('http://www.altavista.com/web/results?itag=ody&q=' + document.forms['search_block'].keywords.value + '&kgs=0&kls=0', '_altavista', '');
\t\t\t\t\t\treturn false;
\t\tcase 'lycos':
\t\t\t\t\t\twindow.open('http://search.lycos.com/?query=' + document.forms['search_block'].keywords.value, '_lycos', '');
\t\t\t\t\t\treturn false;

\t\tcase 'site':\tbreak;
\t\tdefault:\t\tbreak;
\t}
\treturn true;
}
// ]]>
</script>

<form method=\"get\" id=\"search_block\" action=\"";
            // line 34
            echo (isset($context["U_SEARCH"]) ? $context["U_SEARCH"] : null);
            echo "\" onsubmit=\"return url_search()\">
\t<div class=\"block_data\">
\t\t<div style=\"text-align:center;\">
\t\t\t<input class=\"inputbox search\" type=\"text\" name=\"keywords\" size=\"21\" />";
            // line 37
            echo (isset($context["S_HIDDEN_FIELDS"]) ? $context["S_HIDDEN_FIELDS"] : null);
            echo "
\t\t</div>
\t\t<div style=\"padding-top:5px; width:99%;\"></div>
\t\t<div style=\"text-align:center;\">
\t\t\t<select class=\"inputbox full\" style=\"font-size:11px; padding:2px; cursor: pointer;\" name=\"search_engine\">
                <optgroup label=\"";
            // line 42
            echo (isset($context["SITE_NAME"]) ? $context["SITE_NAME"] : null);
            echo "\">
\t\t\t\t\t<option value=\"site\" style=\"font-size:11px;\" >";
            // line 43
            echo (isset($context["SITE_NAME"]) ? $context["SITE_NAME"] : null);
            echo "</option>
\t\t\t\t\t<option value=\"site\">";
            // line 44
            echo $this->env->getExtension('phpbb')->lang("POSTS");
            echo "</option>
\t\t\t\t\t<option value=\"advanced\">";
            // line 45
            echo $this->env->getExtension('phpbb')->lang("ADVANCED_SEARCH");
            echo "</option>
\t\t\t    </optgroup>
                <optgroup style=\"font-size:12px;\" label=\"Search Engine\">
\t\t            <option value=\"google\">Google</option>
\t\t\t        <option value=\"yahoo\">Yahoo</option>
\t\t\t        <option value=\"lycos\">Lycos</option>
                </optgroup>
\t\t\t</select>
\t\t</div>
\t\t<br />
\t\t<div style=\"text-align:center;\">
\t\t\t<input type=\"hidden\" name=\"search_fields\" value=\"all\" />
\t\t\t<input type=\"hidden\" name=\"show_results\" value=\"topics\" />
\t\t\t<input class=\"button1\" type=\"submit\" value=\"";
            // line 58
            echo $this->env->getExtension('phpbb')->lang("SEARCH");
            echo "\" />
\t\t\t<br /><br />
\t\t\t<a href=\"";
            // line 60
            echo (isset($context["U_SEARCH"]) ? $context["U_SEARCH"] : null);
            echo "\">";
            echo $this->env->getExtension('phpbb')->lang("ADVANCED_SEARCH");
            echo "</a>
\t\t</div>
\t\t";
            // line 62
            if ((isset($context["DEBUG_QUERIES"]) ? $context["DEBUG_QUERIES"] : null)) {
                echo "<div class=\"block_data\">";
                echo (isset($context["SEARCH_DEBUG"]) ? $context["SEARCH_DEBUG"] : null);
                echo "</div>";
            }
            // line 63
            echo "\t</div>
</form>
";
        } else {
            // line 66
            echo $this->env->getExtension('phpbb')->lang("LOGIN_TO_USE_SEARCH");
            echo "
";
        }
        // line 68
        echo "<!-- IDTAG ends block_search -->";
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/blocks/block_search.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  130 => 68,  125 => 66,  120 => 63,  114 => 62,  107 => 60,  102 => 58,  86 => 45,  82 => 44,  78 => 43,  74 => 42,  66 => 37,  60 => 34,  34 => 11,  24 => 3,  22 => 2,  19 => 1,);
    }
}
/* <!-- IDTAG starts block_search.html 17 March 2008 copyright phpbbireland.com 2007 -->*/
/* <!-- IF S_SEARCH -->*/
/* */
/* <script type="text/javascript">*/
/* // <![CDATA[*/
/* function url_search()*/
/* {*/
/* 	switch(document.forms['search_block'].search_engine.value)*/
/* 	{*/
/* 		case 'advanced':*/
/* 						window.open('{U_SEARCH}', '_self', '');*/
/* 						return false;*/
/* 		case 'google':*/
/* 						window.open('http://www.google.com/search?q=' + document.forms['search_block'].keywords.value, '_google', '');*/
/* 						return false;*/
/* 		case 'yahoo':*/
/* 						window.open('http://search.yahoo.com/search?p=' + document.forms['search_block'].keywords.value, '_yahoo', '');*/
/* 						return false;*/
/* 		case 'altavista':*/
/* 						window.open('http://www.altavista.com/web/results?itag=ody&q=' + document.forms['search_block'].keywords.value + '&kgs=0&kls=0', '_altavista', '');*/
/* 						return false;*/
/* 		case 'lycos':*/
/* 						window.open('http://search.lycos.com/?query=' + document.forms['search_block'].keywords.value, '_lycos', '');*/
/* 						return false;*/
/* */
/* 		case 'site':	break;*/
/* 		default:		break;*/
/* 	}*/
/* 	return true;*/
/* }*/
/* // ]]>*/
/* </script>*/
/* */
/* <form method="get" id="search_block" action="{U_SEARCH}" onsubmit="return url_search()">*/
/* 	<div class="block_data">*/
/* 		<div style="text-align:center;">*/
/* 			<input class="inputbox search" type="text" name="keywords" size="21" />{S_HIDDEN_FIELDS}*/
/* 		</div>*/
/* 		<div style="padding-top:5px; width:99%;"></div>*/
/* 		<div style="text-align:center;">*/
/* 			<select class="inputbox full" style="font-size:11px; padding:2px; cursor: pointer;" name="search_engine">*/
/*                 <optgroup label="{SITE_NAME}">*/
/* 					<option value="site" style="font-size:11px;" >{SITE_NAME}</option>*/
/* 					<option value="site">{L_POSTS}</option>*/
/* 					<option value="advanced">{L_ADVANCED_SEARCH}</option>*/
/* 			    </optgroup>*/
/*                 <optgroup style="font-size:12px;" label="Search Engine">*/
/* 		            <option value="google">Google</option>*/
/* 			        <option value="yahoo">Yahoo</option>*/
/* 			        <option value="lycos">Lycos</option>*/
/*                 </optgroup>*/
/* 			</select>*/
/* 		</div>*/
/* 		<br />*/
/* 		<div style="text-align:center;">*/
/* 			<input type="hidden" name="search_fields" value="all" />*/
/* 			<input type="hidden" name="show_results" value="topics" />*/
/* 			<input class="button1" type="submit" value="{L_SEARCH}" />*/
/* 			<br /><br />*/
/* 			<a href="{U_SEARCH}">{L_ADVANCED_SEARCH}</a>*/
/* 		</div>*/
/* 		<!-- IF DEBUG_QUERIES --><div class="block_data">{SEARCH_DEBUG}</div><!-- ENDIF -->*/
/* 	</div>*/
/* </form>*/
/* <!-- ELSE -->*/
/* {L_LOGIN_TO_USE_SEARCH}*/
/* <!-- ENDIF -->*/
/* <!-- IDTAG ends block_search -->*/
