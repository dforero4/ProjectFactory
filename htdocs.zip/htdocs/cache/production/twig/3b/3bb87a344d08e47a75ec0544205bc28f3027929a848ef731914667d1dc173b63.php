<?php

/* @phpbbireland_portal/portal_layout_right.html */
class __TwigTemplate_8cef369eea80991071093ea6d50369dc2931c85e39e8a752854b5fb19f42db56 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["loops"]) ? $context["loops"] : null), "right_block_files", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["right_block_files"]) {
            // line 2
            echo "\t<div id=\"";
            if ((isset($context["S_ARRANGE"]) ? $context["S_ARRANGE"] : null)) {
                echo "BLOCK_";
            }
            echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCK_ID", array());
            echo "\">
\t\t<div class=\"forabg sgp-corners\" style=\"margin-bottom:10px;\">
\t\t\t<div class=\"inner\"><span class=\"corners-top\"><span></span></span>

\t\t\t\t<div class=\"block_header ";
            // line 6
            if ((isset($context["S_ARRANGE"]) ? $context["S_ARRANGE"] : null)) {
                echo "handle";
            }
            echo "\">
\t\t\t\t\t<div class=\"block_title\" style=\"text-align:";
            // line 7
            echo (isset($context["S_CONTENT_FLOW_BEGIN"]) ? $context["S_CONTENT_FLOW_BEGIN"] : null);
            echo ";\">
\t\t\t\t\t\t";
            // line 8
            echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCK_TITLE", array());
            echo "
\t\t\t\t\t\t<div style=\"text-align:";
            // line 9
            echo (isset($context["S_CONTENT_FLOW_BEGIN"]) ? $context["S_CONTENT_FLOW_BEGIN"] : null);
            echo ";\" id=\"p_";
            echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCK_ID", array());
            echo "\">
\t\t\t\t\t\t\t";
            // line 10
            if ((isset($context["S_ARRANGE"]) ? $context["S_ARRANGE"] : null)) {
                // line 11
                echo "\t\t\t\t\t\t\t<span class=\"bmove\">";
                echo (isset($context["MOVE_IMG"]) ? $context["MOVE_IMG"] : null);
                echo "</span>
\t\t\t\t\t\t\t<a href=\"javascript:ShowHide('";
                // line 12
                echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCK_ID", array());
                echo "','_";
                echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCK_ID", array());
                echo "','BLOCK_";
                echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCK_ID", array());
                echo "');\">
\t\t\t\t\t\t\t\t<span class=\"bchide\">";
                // line 13
                echo (isset($context["HIDE_IMG"]) ? $context["HIDE_IMG"] : null);
                echo "</span>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t";
            } else {
                // line 16
                echo "\t\t\t\t\t\t\t<span class=\"bcimage\"><img src=\"";
                echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCK_IMG", array());
                echo "\" alt=\"\" /></span>
\t\t\t\t\t\t\t";
            }
            // line 18
            echo "\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div class=\"box\" id=\"";
            // line 22
            if ( !(isset($context["S_ARRANGE"]) ? $context["S_ARRANGE"] : null)) {
                echo "BLOCK_";
            }
            echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCK_ID", array());
            echo "\">
\t\t\t\t\t";
            // line 23
            if ($this->getAttribute($context["right_block_files"], "RIGHT_BLOCK_SCROLL", array())) {
                // line 24
                echo "\t\t\t\t\t\t";
                if ((isset($context["S_ARRANGE"]) ? $context["S_ARRANGE"] : null)) {
                    // line 25
                    echo "\t\t\t\t\t\t\t";
                    echo $this->env->getExtension('phpbb')->lang("SCROLLING_BLOCKS_DISABLED");
                    echo "
\t\t\t\t\t\t";
                } else {
                    // line 27
                    echo "\t\t\t\t\t\t\t<div class=\"scroll_outer\" id=\"";
                    echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCK_ID", array());
                    echo "_outer\" onmouseover=\"do_speed(this, event)\" onmousemove=\"do_speed(this, event)\" onmouseout=\"set_defaults(this, event)\"><div class=\"scroll_inner\" id=\"";
                    echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCK_ID", array());
                    echo "_inner\">";
                    echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCKS", array());
                    echo "</div></div>
\t\t\t\t\t\t";
                }
                // line 29
                echo "\t\t\t\t\t";
            } else {
                // line 30
                echo "\t\t\t\t\t\t";
                echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCKS", array());
                echo "
\t\t\t\t\t";
            }
            // line 32
            echo "\t\t\t\t</div>

\t\t\t<span class=\"corners-bottom\"><span></span></span></div>
\t\t</div>
\t\t<script type=\"text/javascript\">
\t\t// <![CDATA[
\t\t\tif(GetCookie('BLOCK_";
            // line 38
            echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCK_ID", array());
            echo "') == '2')
\t\t\t{
\t\t\t\tShowHide('";
            // line 40
            echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCK_ID", array());
            echo "','_";
            echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCK_ID", array());
            echo "','BLOCK_";
            echo $this->getAttribute($context["right_block_files"], "RIGHT_BLOCK_ID", array());
            echo "');
\t\t\t}
\t\t// ]]>
\t\t</script>
\t</div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['right_block_files'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "
";
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/portal_layout_right.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  153 => 46,  137 => 40,  132 => 38,  124 => 32,  118 => 30,  115 => 29,  105 => 27,  99 => 25,  96 => 24,  94 => 23,  87 => 22,  81 => 18,  75 => 16,  69 => 13,  61 => 12,  56 => 11,  54 => 10,  48 => 9,  44 => 8,  40 => 7,  34 => 6,  23 => 2,  19 => 1,);
    }
}
/* <!-- BEGIN right_block_files -->*/
/* 	<div id="<!-- IF S_ARRANGE -->BLOCK_<!-- ENDIF -->{right_block_files.RIGHT_BLOCK_ID}">*/
/* 		<div class="forabg sgp-corners" style="margin-bottom:10px;">*/
/* 			<div class="inner"><span class="corners-top"><span></span></span>*/
/* */
/* 				<div class="block_header <!-- IF S_ARRANGE -->handle<!-- ENDIF -->">*/
/* 					<div class="block_title" style="text-align:{S_CONTENT_FLOW_BEGIN};">*/
/* 						{right_block_files.RIGHT_BLOCK_TITLE}*/
/* 						<div style="text-align:{S_CONTENT_FLOW_BEGIN};" id="p_{right_block_files.RIGHT_BLOCK_ID}">*/
/* 							<!-- IF S_ARRANGE -->*/
/* 							<span class="bmove">{MOVE_IMG}</span>*/
/* 							<a href="javascript:ShowHide('{right_block_files.RIGHT_BLOCK_ID}','_{right_block_files.RIGHT_BLOCK_ID}','BLOCK_{right_block_files.RIGHT_BLOCK_ID}');">*/
/* 								<span class="bchide">{HIDE_IMG}</span>*/
/* 							</a>*/
/* 							<!-- ELSE -->*/
/* 							<span class="bcimage"><img src="{right_block_files.RIGHT_BLOCK_IMG}" alt="" /></span>*/
/* 							<!-- ENDIF -->*/
/* 						</div>*/
/* 					</div>*/
/* 				</div>*/
/* */
/* 				<div class="box" id="<!-- IF not S_ARRANGE -->BLOCK_<!-- ENDIF -->{right_block_files.RIGHT_BLOCK_ID}">*/
/* 					<!-- IF right_block_files.RIGHT_BLOCK_SCROLL -->*/
/* 						<!-- IF S_ARRANGE -->*/
/* 							{L_SCROLLING_BLOCKS_DISABLED}*/
/* 						<!-- ELSE -->*/
/* 							<div class="scroll_outer" id="{right_block_files.RIGHT_BLOCK_ID}_outer" onmouseover="do_speed(this, event)" onmousemove="do_speed(this, event)" onmouseout="set_defaults(this, event)"><div class="scroll_inner" id="{right_block_files.RIGHT_BLOCK_ID}_inner">{right_block_files.RIGHT_BLOCKS}</div></div>*/
/* 						<!-- ENDIF -->*/
/* 					<!-- ELSE -->*/
/* 						{right_block_files.RIGHT_BLOCKS}*/
/* 					<!-- ENDIF -->*/
/* 				</div>*/
/* */
/* 			<span class="corners-bottom"><span></span></span></div>*/
/* 		</div>*/
/* 		<script type="text/javascript">*/
/* 		// <![CDATA[*/
/* 			if(GetCookie('BLOCK_{right_block_files.RIGHT_BLOCK_ID}') == '2')*/
/* 			{*/
/* 				ShowHide('{right_block_files.RIGHT_BLOCK_ID}','_{right_block_files.RIGHT_BLOCK_ID}','BLOCK_{right_block_files.RIGHT_BLOCK_ID}');*/
/* 			}*/
/* 		// ]]>*/
/* 		</script>*/
/* 	</div>*/
/* <!-- END right_block_files -->*/
/* */
/* */
