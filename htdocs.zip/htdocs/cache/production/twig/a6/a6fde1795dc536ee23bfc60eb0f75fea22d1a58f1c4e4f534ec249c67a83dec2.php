<?php

/* @phpbbireland_portal/set-width.html */
class __TwigTemplate_9eb61db79a0ebf6ea105d7fd19d5e6f81b3953162dcfc74b3a88dfa691045476 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if ((isset($context["RESIZE"]) ? $context["RESIZE"] : null)) {
            // line 2
            echo "<script type=\"text/javascript\">
// <![CDATA[
\tvar trigger = Get_Cookie('styletrigger');
\tvar wvalue = Get_Cookie('stylewidth');
\tjQuery(\"#page-width\").css(\"width:\", wvalue + '%');
// ]]>
</script>
<div id=\"slider\" style=\"width:96%; margin:10px auto;\"></div>
";
        }
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/set-width.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  21 => 2,  19 => 1,);
    }
}
/* <!-- IF RESIZE -->*/
/* <script type="text/javascript">*/
/* // <![CDATA[*/
/* 	var trigger = Get_Cookie('styletrigger');*/
/* 	var wvalue = Get_Cookie('stylewidth');*/
/* 	jQuery("#page-width").css("width:", wvalue + '%');*/
/* // ]]>*/
/* </script>*/
/* <div id="slider" style="width:96%; margin:10px auto;"></div>*/
/* <!-- ENDIF -->*/
