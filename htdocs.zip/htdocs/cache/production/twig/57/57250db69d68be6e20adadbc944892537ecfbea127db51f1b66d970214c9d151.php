<?php

/* @phpbbireland_portal/event/overall_footer_copyright_append.html */
class __TwigTemplate_2b612eb5f77620d8f867227c198c83ee11366943e8674693b339666f88e59bce extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if ((isset($context["KISS"]) ? $context["KISS"] : null)) {
            // line 2
            echo "\t";
            $location = "portal_copyright.html";
            $namespace = false;
            if (strpos($location, '@') === 0) {
                $namespace = substr($location, 1, strpos($location, '/') - 1);
                $previous_look_up_order = $this->env->getNamespaceLookUpOrder();
                $this->env->setNamespaceLookUpOrder(array($namespace, '__main__'));
            }
            $this->loadTemplate("portal_copyright.html", "@phpbbireland_portal/event/overall_footer_copyright_append.html", 2)->display($context);
            if ($namespace) {
                $this->env->setNamespaceLookUpOrder($previous_look_up_order);
            }
        }
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/event/overall_footer_copyright_append.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  21 => 2,  19 => 1,);
    }
}
/* <!-- IF KISS -->*/
/* 	<!-- INCLUDE portal_copyright.html -->*/
/* <!-- ENDIF -->*/
