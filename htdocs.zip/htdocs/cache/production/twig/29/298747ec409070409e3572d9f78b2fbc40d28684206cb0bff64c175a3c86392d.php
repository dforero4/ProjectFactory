<?php

/* @phpbbireland_portal/portal_scripts.html */
class __TwigTemplate_c76cd57a390313f35f2c98c64db364acb0834fed93f9aa7d9bfed45af934732d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $asset_file = "assets/portal.js";
        $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
        if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
            $asset_path = $asset->get_path();            $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
            if (!file_exists($local_file)) {
                $local_file = $this->getEnvironment()->findTemplate($asset_path);
                $asset->set_path($local_file, true);
            }
            $asset->add_assets_version('4');
        }
        $this->getEnvironment()->get_assets_bag()->add_script($asset);        // line 2
        echo "
<script type=\"text/javascript\">
// <![CDATA[
\t/**
\t* New function for handling multiple calls to window.onload and window.unload by pentapenguin
\t*/

\tvar onload_functions = new Array();
\tvar onunload_functions = new Array();

\twindow.onload = function()
\t{
\t\tfor (var i = 0; i < onload_functions.length; i++)
\t\t{
\t\t\teval(onload_functions[i]);
\t\t}
\t}

\twindow.onunload = function()
\t{
\t\tfor (var i = 0; i < onunload_functions.length; i++)
\t\t{
\t\t\teval(onunload_functions[i]);
\t\t}
\t}

\tonload_functions.push('init_scrollers()');
//alert('scripts');
// ]]>
</script>

<link rel=\"shortcut icon\" href=\"favicon.ico\" />
<link rel=\"icon\" href=\"favicon.ico\" type=\"image/x-icon\" />

";
        // line 36
        $asset_file = "assets/scroller.js";
        $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
        if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
            $asset_path = $asset->get_path();            $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
            if (!file_exists($local_file)) {
                $local_file = $this->getEnvironment()->findTemplate($asset_path);
                $asset->set_path($local_file, true);
            }
            $asset->add_assets_version('4');
        }
        $this->getEnvironment()->get_assets_bag()->add_script($asset);        // line 37
        echo "
";
        // line 38
        if (((isset($context["S_IS_PORTAL"]) ? $context["S_IS_PORTAL"] : null) && (isset($context["S_ARRANGE"]) ? $context["S_ARRANGE"] : null))) {
            // line 39
            echo "\t";
            $asset_file = "assets/drag_n_drop/prototype.js";
            $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
            if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
                $asset_path = $asset->get_path();                $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
                if (!file_exists($local_file)) {
                    $local_file = $this->getEnvironment()->findTemplate($asset_path);
                    $asset->set_path($local_file, true);
                }
                $asset->add_assets_version('4');
            }
            $this->getEnvironment()->get_assets_bag()->add_script($asset);            // line 40
            echo "\t";
            $asset_file = "assets/drag_n_drop/scriptaculous.js";
            $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
            if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
                $asset_path = $asset->get_path();                $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
                if (!file_exists($local_file)) {
                    $local_file = $this->getEnvironment()->findTemplate($asset_path);
                    $asset->set_path($local_file, true);
                }
                $asset->add_assets_version('4');
            }
            $this->getEnvironment()->get_assets_bag()->add_script($asset);            // line 41
            echo "\t";
            $asset_file = "assets/drag_n_drop/builder.js";
            $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
            if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
                $asset_path = $asset->get_path();                $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
                if (!file_exists($local_file)) {
                    $local_file = $this->getEnvironment()->findTemplate($asset_path);
                    $asset->set_path($local_file, true);
                }
                $asset->add_assets_version('4');
            }
            $this->getEnvironment()->get_assets_bag()->add_script($asset);            // line 42
            echo "\t";
            $asset_file = "assets/drag_n_drop/dragdrop.js";
            $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
            if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
                $asset_path = $asset->get_path();                $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
                if (!file_exists($local_file)) {
                    $local_file = $this->getEnvironment()->findTemplate($asset_path);
                    $asset->set_path($local_file, true);
                }
                $asset->add_assets_version('4');
            }
            $this->getEnvironment()->get_assets_bag()->add_script($asset);            // line 43
            echo "\t";
            $asset_file = "assets/drag_n_drop/effects.js";
            $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
            if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
                $asset_path = $asset->get_path();                $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
                if (!file_exists($local_file)) {
                    $local_file = $this->getEnvironment()->findTemplate($asset_path);
                    $asset->set_path($local_file, true);
                }
                $asset->add_assets_version('4');
            }
            $this->getEnvironment()->get_assets_bag()->add_script($asset);            // line 44
            echo "\t";
            $asset_file = "assets/drag_n_drop/controls.js";
            $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
            if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
                $asset_path = $asset->get_path();                $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
                if (!file_exists($local_file)) {
                    $local_file = $this->getEnvironment()->findTemplate($asset_path);
                    $asset->set_path($local_file, true);
                }
                $asset->add_assets_version('4');
            }
            $this->getEnvironment()->get_assets_bag()->add_script($asset);            // line 45
            echo "\t";
            $asset_file = "assets/drag_n_drop/slider.js";
            $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
            if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
                $asset_path = $asset->get_path();                $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
                if (!file_exists($local_file)) {
                    $local_file = $this->getEnvironment()->findTemplate($asset_path);
                    $asset->set_path($local_file, true);
                }
                $asset->add_assets_version('4');
            }
            $this->getEnvironment()->get_assets_bag()->add_script($asset);            // line 46
            echo "\t";
            $asset_file = "assets/drag_n_drop/unittest.js";
            $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
            if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
                $asset_path = $asset->get_path();                $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
                if (!file_exists($local_file)) {
                    $local_file = $this->getEnvironment()->findTemplate($asset_path);
                    $asset->set_path($local_file, true);
                }
                $asset->add_assets_version('4');
            }
            $this->getEnvironment()->get_assets_bag()->add_script($asset);        }
        // line 48
        echo "
";
        // line 49
        if ((isset($context["S_HIGHSLIDE"]) ? $context["S_HIGHSLIDE"] : null)) {
            // line 50
            $asset_file = "assets/highslide/highslide-full.packed.js";
            $asset = new \phpbb\template\asset($asset_file, $this->getEnvironment()->get_path_helper(), $this->getEnvironment()->get_filesystem());
            if (substr($asset_file, 0, 2) !== './' && $asset->is_relative()) {
                $asset_path = $asset->get_path();                $local_file = $this->getEnvironment()->get_phpbb_root_path() . $asset_path;
                if (!file_exists($local_file)) {
                    $local_file = $this->getEnvironment()->findTemplate($asset_path);
                    $asset->set_path($local_file, true);
                }
                $asset->add_assets_version('4');
            }
            $this->getEnvironment()->get_assets_bag()->add_script($asset);            // line 51
            echo "
<script type=\"text/javascript\" src=\"./ext/phpbbireland/portal/js/highslide/highslide-full.packed.js\"></script>
<link rel=\"stylesheet\" type=\"text/css\" href=\"./ext/phpbbireland/portal/js/highslide/highslide.css\" />

<script type=\"text/javascript\">
// <![CDATA[
\ths.graphicsDir = './ext/phpbbireland/portal/js/highslide/graphics/';
\ths.align = 'center';
\ths.transitions = ['expand', 'crossfade'];
\ths.outlineType = 'glossy-dark';
\ths.wrapperClassName = 'dark';
\ths.fadeInOut = true;
\t//hs.dimmingOpacity = 0.75;

\t// Add the controlbar
\tif (hs.addSlideshow) hs.addSlideshow({
\t\t//slideshowGroup: 'group1',
\t\tinterval: 5000,
\t\trepeat: false,
\t\tuseControls: true,
\t\tfixedControls: 'fit',
\t\toverlayOptions: {
\t\t\topacity: .6,
\t\t\tposition: 'bottom center',
\t\t\thideOnMouseOut: true
\t\t}
\t});
// ]]>
</script>
";
        }
        // line 81
        echo "
<link rel=\"stylesheet\" href=\"";
        // line 82
        echo (isset($context["T_STYLESHEET_PORTAL_COMMON"]) ? $context["T_STYLESHEET_PORTAL_COMMON"] : null);
        echo "\" type=\"text/css\" />

<!-- xINCLUDEJS assets/jquery/jquery.js -->
<!-- xINCLUDEJS assets/jquery/jquery.hoverIntent.js -->
<!-- xINCLUDEJS assets/jquery/imgbubbles.js -->

<script type=\"text/javascript\" src=\"./ext/phpbbireland/portal/js/portal.js\"></script>

<script type=\"text/javascript\" src=\"./ext/phpbbireland/portal/js/jquery/jquery.js\"></script>
<script type=\"text/javascript\" src=\"./ext/phpbbireland/portal/js/jquery/jquery.hoverIntent.js\"></script>
<script type=\"text/javascript\" src=\"./ext/phpbbireland/portal/js/jquery/imgbubbles.js\"></script>

<script type=\"text/javascript\" src=\"./ext/phpbbireland/portal/js/jquery/jquery_ui/jquery-ui.min.js\"></script>
<script type=\"text/javascript\" src=\"./ext/phpbbireland/portal/js/jquery/youtube/jquery.youtubepopup.js\"></script>

<!--
<script type=\"text/javascript\">
//<![CDATA[

\tvar \$css_file_append = 'fix_ff.css';

\tif (/MSIE (\\d+\\.\\d+);/.test(navigator.userAgent))
\t{
\t\tvar ieversion = new Number(RegExp.\$1)
\t\t\$css_file_append = 'fix_ie_' + ieversion + '.css';
\t}
\telse if (/Firefox[\\/\\s](\\d+\\.\\d+)/.test(navigator.userAgent))
\t{
\t\tvar ffversion=new Number(RegExp.\$1)
\t\t\$css_file_append = 'fix_ff.css';
\t}
\telse if (/Opera[\\/\\s](\\d+\\.\\d+)/.test(navigator.userAgent))
\t{
\t\tvar oprversion=new Number(RegExp.\$1)
\t\t\$css_file_append = 'fix_opera.css';
\t}
\telse if (/Safari[\\/\\s](\\d+\\.\\d+)/.test(navigator.userAgent))
\t{
\t\tvar oprversion=new Number(RegExp.\$1)
\t\t\$css_file_append = 'fix_mac.css';
\t}

\tjQuery.noConflict();
\tjQuery(document).ready(function(){
\t\tjQuery('<link rel=\"stylesheet\" href=\"";
        // line 126
        echo (isset($context["T_IMAGE_PATH"]) ? $context["T_IMAGE_PATH"] : null);
        echo "theme/' + \$css_file_append + '\" type=\"text/css\" />').appendTo('body');
\t});

//]]>
</script>
-->
<!-- agent script end -->


";
        // line 135
        if ((isset($context["S_VIEWTOPIC"]) ? $context["S_VIEWTOPIC"] : null)) {
            // line 136
            echo "<script type=\"text/javascript\">
// <![CDATA[
\tjQuery.noConflict();
\tjQuery(document).ready(function()
\t{
\t\tvar i = 0;

\t\t// hides the quick reply box as soon as the DOM is ready - (a little sooner than page load)
\t\tjQuery('.fastreply').hide();

\t\t// toggles the quick reply box on clicking the quick reply button
\t\tjQuery('a.qreply-icon').click(function()
\t\t{
\t\t\tjQuery('.fastreply').toggle(400);

\t\t\t// lets toggle the image the easy way ;)
\t\t\tif (i == 0)
\t\t\t{
\t\t\t\tjQuery(this).css({'background' : 'url(\"";
            // line 154
            echo (isset($context["T_IMAGESET_LANG_PATH"]) ? $context["T_IMAGESET_LANG_PATH"] : null);
            echo "/button_topic_qreply_no.png\") 0 0 no-repeat'});
\t\t\t\ti++;
\t\t\t}
\t\t\telse if (i == 1)
\t\t\t{
\t\t\t\tjQuery(this).css({'background' : 'url(\"";
            // line 159
            echo (isset($context["T_IMAGESET_LANG_PATH"]) ? $context["T_IMAGESET_LANG_PATH"] : null);
            echo "/button_topic_qreply.png\") 0 0 no-repeat'});
\t\t\t\ti = 0
\t\t\t}
\t\t\treturn false;
\t\t});
\t});
//]]>
</script>
";
        }
        // line 168
        echo "
<script type=\"text/javascript\">
// <![CDATA[

\tjQuery.noConflict();
\tjQuery(document).ready(function(\$){

\tvar \$m = null;

\tjQuery(\".hidden_part\").hide();

\tjQuery(\".bg1a\").mousedown(function(){

\t\t// accordian effect uncomment
\t\tif (\$m != null)
\t\t{
\t\t\tjQuery(\".hidden_part\").fadeOut(500);
\t\t\tjQuery(\$m + '>' + '.laro').css({'background' : 'url(\"";
        // line 185
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/portal/raro.gif\") 0 0 no-repeat'});
\t\t}
\t\telse
\t\t{
\t\t\t\$m = '#'+this.id;
\t\t\tjQuery(\$m + '>' + '.laro').css({'background' : 'url(\"";
        // line 190
        echo (isset($context["T_THEME_PATH"]) ? $context["T_THEME_PATH"] : null);
        echo "/images/portal/daro.gif\") 0 0 no-repeat'});
\t\t}


\t\tjQuery('#T'+this.id).delay(100).toggle(400);

\t\t}).mouseleave(function(){
\t\t//jQuery('#T'+this.id).delay(600);
\t\t});
\t});

\tjQuery(function(){
\t\tjQuery('a[rel=\"external\"]').attr('target','_blank');
\t});

//]]>
</script>
<script type=\"text/javascript\">
// <![CDATA[

\tjQuery.noConflict();
\tjQuery(function (jQuery) {
\t\tjQuery(\"a.youtube\").YouTubePopup({ autoplay: ";
        // line 212
        if ((isset($context["S_AUTOPLAY"]) ? $context["S_AUTOPLAY"] : null)) {
            echo "1";
        } else {
            echo "0";
        }
        echo " });
\t});

//]]>
</script>
<script type=\"text/javascript\">
// <![CDATA[

\tjQuery.noConflict();
\tjQuery(document).ready(function(jQuery){
\t\tjQuery('.ximg').imgbubbles({factor:5});
\t})

\tjQuery(document).ready(function(){
\tjQuery(\".vido\").click(function () {
\t\tjQuery(\"#vdo\").hide(\"slide\", {}, 1000);
\t\t});
\t});

\tjQuery(document).ready(function(){
\t\tjQuery('.accordion').click(function() {
\t\t\t\$(this).next().toggle('slow');
\t\t\treturn false;
\t\t}).next().hide();
\t});

//]]>
</script>

";
        // line 241
        if ((isset($context["RESIZE"]) ? $context["RESIZE"] : null)) {
            // line 242
            echo "<link href=\"http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css\" rel=\"stylesheet\" type=\"text/css\"/>

<script src=\"http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js\"></script>

<script type=\"text/javascript\">
// <![CDATA[

var w = 100;
x = Get_Cookie('stylewidth');
if(x)
{
\tw = x;
}

jQuery.noConflict();
jQuery(document).ready(function(){
\tjQuery(function() {
\t\tjQuery(\"#slider\").slider({
\t\t\torientation: \"horizontal\",
\t\t\trange: \"min\",
\t\t\tmax: 100,
\t\t\tvalue: 50,
\t\t\tslide: refreshWidth,
\t\t\tchange: refreshWidth
\t\t});
\t\tjQuery(\"#page-width\").css(\"width\", w + '%');
\t});
\tfunction refreshWidth()
\t{
\t\tw = jQuery(\"#slider\").slider(\"value\");
\t\tpc = ((w/100) * 100);
\t\tw = pc;

\t\tjQuery(\"#page-width\").css(\"width\", w + '%');
\t}
\tjQuery(\"#slider\").slider({
\t   stop: function(event) {
\t\t   Set_Cookie('stylewidth', w);
\t\t   jQuery(\"#slider\").css(\"display\", 'none');
\t   }
\t});

});
//]]>
</script>
";
        }
        // line 288
        echo "

<!--
\tFix annoying white flash on page load michaelo 2013
\tset css class flash (flash movie) to display:none as default
-->
<script type=\"text/javascript\">
// <![CDATA[
\t// make sure flash is not displayed //
\tjQuery(\".flash\").css(\"display\", 'none');
\tjQuery(document).ready(function () {
\t\tsetTimeout(function(){
\t\t\tjQuery(\".flash\").css(\"display\", 'block');
\t\t\t//jQuery('.flash').fadeIn(500);
\t}, 500);
});
//]]>
</script>";
    }

    public function getTemplateName()
    {
        return "@phpbbireland_portal/portal_scripts.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  469 => 288,  421 => 242,  419 => 241,  383 => 212,  358 => 190,  350 => 185,  331 => 168,  319 => 159,  311 => 154,  291 => 136,  289 => 135,  277 => 126,  230 => 82,  227 => 81,  195 => 51,  184 => 50,  182 => 49,  179 => 48,  166 => 46,  154 => 45,  142 => 44,  130 => 43,  118 => 42,  106 => 41,  94 => 40,  82 => 39,  80 => 38,  77 => 37,  66 => 36,  30 => 2,  19 => 1,);
    }
}
/* <!-- INCLUDEJS assets/portal.js -->*/
/* */
/* <script type="text/javascript">*/
/* // <![CDATA[*/
/* 	/***/
/* 	* New function for handling multiple calls to window.onload and window.unload by pentapenguin*/
/* 	*//* */
/* */
/* 	var onload_functions = new Array();*/
/* 	var onunload_functions = new Array();*/
/* */
/* 	window.onload = function()*/
/* 	{*/
/* 		for (var i = 0; i < onload_functions.length; i++)*/
/* 		{*/
/* 			eval(onload_functions[i]);*/
/* 		}*/
/* 	}*/
/* */
/* 	window.onunload = function()*/
/* 	{*/
/* 		for (var i = 0; i < onunload_functions.length; i++)*/
/* 		{*/
/* 			eval(onunload_functions[i]);*/
/* 		}*/
/* 	}*/
/* */
/* 	onload_functions.push('init_scrollers()');*/
/* //alert('scripts');*/
/* // ]]>*/
/* </script>*/
/* */
/* <link rel="shortcut icon" href="favicon.ico" />*/
/* <link rel="icon" href="favicon.ico" type="image/x-icon" />*/
/* */
/* <!-- INCLUDEJS assets/scroller.js -->*/
/* */
/* <!-- IF S_IS_PORTAL and S_ARRANGE -->*/
/* 	<!-- INCLUDEJS assets/drag_n_drop/prototype.js -->*/
/* 	<!-- INCLUDEJS assets/drag_n_drop/scriptaculous.js -->*/
/* 	<!-- INCLUDEJS assets/drag_n_drop/builder.js -->*/
/* 	<!-- INCLUDEJS assets/drag_n_drop/dragdrop.js -->*/
/* 	<!-- INCLUDEJS assets/drag_n_drop/effects.js -->*/
/* 	<!-- INCLUDEJS assets/drag_n_drop/controls.js -->*/
/* 	<!-- INCLUDEJS assets/drag_n_drop/slider.js -->*/
/* 	<!-- INCLUDEJS assets/drag_n_drop/unittest.js -->*/
/* <!-- ENDIF -->*/
/* */
/* <!-- IF S_HIGHSLIDE -->*/
/* <!-- INCLUDEJS assets/highslide/highslide-full.packed.js -->*/
/* */
/* <script type="text/javascript" src="./ext/phpbbireland/portal/js/highslide/highslide-full.packed.js"></script>*/
/* <link rel="stylesheet" type="text/css" href="./ext/phpbbireland/portal/js/highslide/highslide.css" />*/
/* */
/* <script type="text/javascript">*/
/* // <![CDATA[*/
/* 	hs.graphicsDir = './ext/phpbbireland/portal/js/highslide/graphics/';*/
/* 	hs.align = 'center';*/
/* 	hs.transitions = ['expand', 'crossfade'];*/
/* 	hs.outlineType = 'glossy-dark';*/
/* 	hs.wrapperClassName = 'dark';*/
/* 	hs.fadeInOut = true;*/
/* 	//hs.dimmingOpacity = 0.75;*/
/* */
/* 	// Add the controlbar*/
/* 	if (hs.addSlideshow) hs.addSlideshow({*/
/* 		//slideshowGroup: 'group1',*/
/* 		interval: 5000,*/
/* 		repeat: false,*/
/* 		useControls: true,*/
/* 		fixedControls: 'fit',*/
/* 		overlayOptions: {*/
/* 			opacity: .6,*/
/* 			position: 'bottom center',*/
/* 			hideOnMouseOut: true*/
/* 		}*/
/* 	});*/
/* // ]]>*/
/* </script>*/
/* <!-- ENDIF -->*/
/* */
/* <link rel="stylesheet" href="{T_STYLESHEET_PORTAL_COMMON}" type="text/css" />*/
/* */
/* <!-- xINCLUDEJS assets/jquery/jquery.js -->*/
/* <!-- xINCLUDEJS assets/jquery/jquery.hoverIntent.js -->*/
/* <!-- xINCLUDEJS assets/jquery/imgbubbles.js -->*/
/* */
/* <script type="text/javascript" src="./ext/phpbbireland/portal/js/portal.js"></script>*/
/* */
/* <script type="text/javascript" src="./ext/phpbbireland/portal/js/jquery/jquery.js"></script>*/
/* <script type="text/javascript" src="./ext/phpbbireland/portal/js/jquery/jquery.hoverIntent.js"></script>*/
/* <script type="text/javascript" src="./ext/phpbbireland/portal/js/jquery/imgbubbles.js"></script>*/
/* */
/* <script type="text/javascript" src="./ext/phpbbireland/portal/js/jquery/jquery_ui/jquery-ui.min.js"></script>*/
/* <script type="text/javascript" src="./ext/phpbbireland/portal/js/jquery/youtube/jquery.youtubepopup.js"></script>*/
/* */
/* <!--*/
/* <script type="text/javascript">*/
/* //<![CDATA[*/
/* */
/* 	var $css_file_append = 'fix_ff.css';*/
/* */
/* 	if (/MSIE (\d+\.\d+);/.test(navigator.userAgent))*/
/* 	{*/
/* 		var ieversion = new Number(RegExp.$1)*/
/* 		$css_file_append = 'fix_ie_' + ieversion + '.css';*/
/* 	}*/
/* 	else if (/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent))*/
/* 	{*/
/* 		var ffversion=new Number(RegExp.$1)*/
/* 		$css_file_append = 'fix_ff.css';*/
/* 	}*/
/* 	else if (/Opera[\/\s](\d+\.\d+)/.test(navigator.userAgent))*/
/* 	{*/
/* 		var oprversion=new Number(RegExp.$1)*/
/* 		$css_file_append = 'fix_opera.css';*/
/* 	}*/
/* 	else if (/Safari[\/\s](\d+\.\d+)/.test(navigator.userAgent))*/
/* 	{*/
/* 		var oprversion=new Number(RegExp.$1)*/
/* 		$css_file_append = 'fix_mac.css';*/
/* 	}*/
/* */
/* 	jQuery.noConflict();*/
/* 	jQuery(document).ready(function(){*/
/* 		jQuery('<link rel="stylesheet" href="{T_IMAGE_PATH}theme/' + $css_file_append + '" type="text/css" />').appendTo('body');*/
/* 	});*/
/* */
/* //]]>*/
/* </script>*/
/* -->*/
/* <!-- agent script end -->*/
/* */
/* */
/* <!-- IF S_VIEWTOPIC -->*/
/* <script type="text/javascript">*/
/* // <![CDATA[*/
/* 	jQuery.noConflict();*/
/* 	jQuery(document).ready(function()*/
/* 	{*/
/* 		var i = 0;*/
/* */
/* 		// hides the quick reply box as soon as the DOM is ready - (a little sooner than page load)*/
/* 		jQuery('.fastreply').hide();*/
/* */
/* 		// toggles the quick reply box on clicking the quick reply button*/
/* 		jQuery('a.qreply-icon').click(function()*/
/* 		{*/
/* 			jQuery('.fastreply').toggle(400);*/
/* */
/* 			// lets toggle the image the easy way ;)*/
/* 			if (i == 0)*/
/* 			{*/
/* 				jQuery(this).css({'background' : 'url("{T_IMAGESET_LANG_PATH}/button_topic_qreply_no.png") 0 0 no-repeat'});*/
/* 				i++;*/
/* 			}*/
/* 			else if (i == 1)*/
/* 			{*/
/* 				jQuery(this).css({'background' : 'url("{T_IMAGESET_LANG_PATH}/button_topic_qreply.png") 0 0 no-repeat'});*/
/* 				i = 0*/
/* 			}*/
/* 			return false;*/
/* 		});*/
/* 	});*/
/* //]]>*/
/* </script>*/
/* <!-- ENDIF -->*/
/* */
/* <script type="text/javascript">*/
/* // <![CDATA[*/
/* */
/* 	jQuery.noConflict();*/
/* 	jQuery(document).ready(function($){*/
/* */
/* 	var $m = null;*/
/* */
/* 	jQuery(".hidden_part").hide();*/
/* */
/* 	jQuery(".bg1a").mousedown(function(){*/
/* */
/* 		// accordian effect uncomment*/
/* 		if ($m != null)*/
/* 		{*/
/* 			jQuery(".hidden_part").fadeOut(500);*/
/* 			jQuery($m + '>' + '.laro').css({'background' : 'url("{T_THEME_PATH}/images/portal/raro.gif") 0 0 no-repeat'});*/
/* 		}*/
/* 		else*/
/* 		{*/
/* 			$m = '#'+this.id;*/
/* 			jQuery($m + '>' + '.laro').css({'background' : 'url("{T_THEME_PATH}/images/portal/daro.gif") 0 0 no-repeat'});*/
/* 		}*/
/* */
/* */
/* 		jQuery('#T'+this.id).delay(100).toggle(400);*/
/* */
/* 		}).mouseleave(function(){*/
/* 		//jQuery('#T'+this.id).delay(600);*/
/* 		});*/
/* 	});*/
/* */
/* 	jQuery(function(){*/
/* 		jQuery('a[rel="external"]').attr('target','_blank');*/
/* 	});*/
/* */
/* //]]>*/
/* </script>*/
/* <script type="text/javascript">*/
/* // <![CDATA[*/
/* */
/* 	jQuery.noConflict();*/
/* 	jQuery(function (jQuery) {*/
/* 		jQuery("a.youtube").YouTubePopup({ autoplay: <!-- IF S_AUTOPLAY -->1<!-- ELSE -->0<!-- ENDIF --> });*/
/* 	});*/
/* */
/* //]]>*/
/* </script>*/
/* <script type="text/javascript">*/
/* // <![CDATA[*/
/* */
/* 	jQuery.noConflict();*/
/* 	jQuery(document).ready(function(jQuery){*/
/* 		jQuery('.ximg').imgbubbles({factor:5});*/
/* 	})*/
/* */
/* 	jQuery(document).ready(function(){*/
/* 	jQuery(".vido").click(function () {*/
/* 		jQuery("#vdo").hide("slide", {}, 1000);*/
/* 		});*/
/* 	});*/
/* */
/* 	jQuery(document).ready(function(){*/
/* 		jQuery('.accordion').click(function() {*/
/* 			$(this).next().toggle('slow');*/
/* 			return false;*/
/* 		}).next().hide();*/
/* 	});*/
/* */
/* //]]>*/
/* </script>*/
/* */
/* <!-- IF RESIZE -->*/
/* <link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>*/
/* */
/* <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>*/
/* */
/* <script type="text/javascript">*/
/* // <![CDATA[*/
/* */
/* var w = 100;*/
/* x = Get_Cookie('stylewidth');*/
/* if(x)*/
/* {*/
/* 	w = x;*/
/* }*/
/* */
/* jQuery.noConflict();*/
/* jQuery(document).ready(function(){*/
/* 	jQuery(function() {*/
/* 		jQuery("#slider").slider({*/
/* 			orientation: "horizontal",*/
/* 			range: "min",*/
/* 			max: 100,*/
/* 			value: 50,*/
/* 			slide: refreshWidth,*/
/* 			change: refreshWidth*/
/* 		});*/
/* 		jQuery("#page-width").css("width", w + '%');*/
/* 	});*/
/* 	function refreshWidth()*/
/* 	{*/
/* 		w = jQuery("#slider").slider("value");*/
/* 		pc = ((w/100) * 100);*/
/* 		w = pc;*/
/* */
/* 		jQuery("#page-width").css("width", w + '%');*/
/* 	}*/
/* 	jQuery("#slider").slider({*/
/* 	   stop: function(event) {*/
/* 		   Set_Cookie('stylewidth', w);*/
/* 		   jQuery("#slider").css("display", 'none');*/
/* 	   }*/
/* 	});*/
/* */
/* });*/
/* //]]>*/
/* </script>*/
/* <!-- ENDIF -->*/
/* */
/* */
/* <!--*/
/* 	Fix annoying white flash on page load michaelo 2013*/
/* 	set css class flash (flash movie) to display:none as default*/
/* -->*/
/* <script type="text/javascript">*/
/* // <![CDATA[*/
/* 	// make sure flash is not displayed //*/
/* 	jQuery(".flash").css("display", 'none');*/
/* 	jQuery(document).ready(function () {*/
/* 		setTimeout(function(){*/
/* 			jQuery(".flash").css("display", 'block');*/
/* 			//jQuery('.flash').fadeIn(500);*/
/* 	}, 500);*/
/* });*/
/* //]]>*/
/* </script>*/
